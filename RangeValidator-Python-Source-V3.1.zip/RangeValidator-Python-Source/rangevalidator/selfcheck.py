﻿"""Explicit distribution self-check: creates its own sanitized files only."""
from pathlib import Path
from openpyxl import Workbook,load_workbook
from .workflow import run_comparison,fingerprint
from .writer import save_selected


def run(folder):
    root=Path(folder).resolve();root.mkdir()
    header=root/'types.h';header.write_text('typedef struct { unsigned int active:1; } Device_t;',encoding='utf-8')
    common=root/'Common.xlsx';w=Workbook();s=w.active;s.append(['File','Name','Type','Value']);s.append(['device.c','p','Device_t *','']);w.save(common);w.close()
    detail=root/'device_Detail.xlsx';w=Workbook();s=w.active;s['A1']='Global(Input)';s.append(['Name','Type','Range']);s.append(['p->active','uint','0~99']);w.save(detail);w.close()
    session=run_comparison(common,[header],[detail])
    selected=[r.id for r in session.results if r.candidate]
    if len(selected)!=1:raise RuntimeError('Self-check candidate mismatch')
    before=fingerprint(detail)
    output,outcomes=save_selected(session,selected,root/'outputs')
    if not all(o['status']=='VERIFIED' for o in outcomes.values()):raise RuntimeError(str(outcomes))
    if fingerprint(detail)!=before:raise RuntimeError('Self-check original changed')
    w=load_workbook(output/detail.name)
    try:
        if w.active['C3'].value!='0~1':raise RuntimeError('Saved value incorrect')
    finally:w.close()
    return dict(candidate_count=1,verified=1,original_preserved=True,report=(output/'RangeValidator_Report.xlsx').is_file(),output=str(output))

"""Korean Tk/ttk GUI. All UI access stays on the main thread."""
from dataclasses import asdict
import json
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from .diagnostics import Diagnostics, format_event, STAGES
from .workflow import run_comparison
from .writer import save_selected, export_all
from .report import create_report


LABELS={'MATCH':'일치','MISMATCH':'불일치','REVIEW':'검토 필요','SKIP':'분석 제외'}


class App:
    def __init__(self,root):
        self.root=root
        root.title('RangeValidator Python V3.1 — 비트필드 범위 검증')
        root.geometry('1320x820')
        root.minsize(1000,640)
        style=ttk.Style(root)
        if 'vista' in style.theme_names():
            style.theme_use('vista')
        style.configure('.',font=('맑은 고딕',9))
        self.queue=queue.Queue()
        self.busy=False
        self.closing=False
        self.session=None
        self.page=0
        self.page_size=1000
        self.selected=set()
        self.outcomes={}
        self.common=''
        self.headers=[]
        self.details=[]
        self.controls=[]
        self.notebook=ttk.Notebook(root)
        self.notebook.pack(fill='both',expand=True,padx=10,pady=10)
        self.tabs=[]
        for title in ('파일 등록','비교 결과','수정 및 저장','진단 로그'):
            tab=ttk.Frame(self.notebook,padding=10)
            self.notebook.add(tab,text=title)
            self.tabs.append(tab)
        self.build_inputs()
        self.build_results()
        self.build_save()
        self.build_logs()
        bottom=ttk.Frame(root,padding=(10,0,10,10))
        bottom.pack(fill='x')
        self.status=tk.StringVar(value='파일을 등록한 뒤 비교를 실행하세요.')
        ttk.Label(bottom,textvariable=self.status).pack(side='left')
        self.progress=ttk.Progressbar(bottom,mode='indeterminate',length=220)
        self.progress.pack(side='right')
        ttk.Button(bottom,text='진단 로그 보기',command=self.show_diagnostics).pack(side='right',padx=8)
        root.protocol('WM_DELETE_WINDOW',self.close)
        self.after_id=root.after(100,self.drain)
        root.bind('<Destroy>',self.on_destroy,add='+')

    def button(self,parent,text,command):
        b=ttk.Button(parent,text=text,command=command)
        self.controls.append(b)
        return b

    def invalidate(self):
        self.session=None
        self.page=0
        self.selected.clear()
        self.outcomes={}
        self.refresh()

    def build_inputs(self):
        tab=self.tabs[0]
        for title,role in [('Common Parameter 파일 (선택)','common'),('C 소스/헤더 파일 (여러 개 — 구조체 정의 .h 와 변수 선언이 있는 .c/.h)','headers'),('상세설계서 XLSX (여러 개)','details')]:
            box=ttk.LabelFrame(tab,text=title,padding=8)
            box.pack(fill='both',expand=True,pady=5)
            bar=ttk.Frame(box)
            bar.pack(fill='x')
            self.button(bar,'파일 추가',lambda r=role:self.add(r)).pack(side='left',padx=3)
            self.button(bar,'선택 삭제',lambda r=role:self.remove(r)).pack(side='left',padx=3)
            self.button(bar,'초기화',lambda r=role:self.clear(r)).pack(side='left',padx=3)
            frame=ttk.Frame(box)
            frame.pack(fill='both',expand=True)
            lb=tk.Listbox(frame,selectmode='extended',height=4,exportselection=False)
            lb.pack(side='left',fill='both',expand=True)
            scroll=ttk.Scrollbar(frame,command=lb.yview)
            scroll.pack(side='right',fill='y')
            lb.configure(yscrollcommand=scroll.set)
            setattr(self,role+'_list',lb)
        bar=ttk.Frame(tab)
        bar.pack(fill='x',pady=10)
        self.button(bar,'비교 실행',self.compare).pack(side='right')
        ttk.Label(bar,text='일반 XLSX 우선 읽기 → 실패 시 승인된 Excel COM 사용 / 원본은 읽기 전용').pack(side='left')

        self.encoding=tk.StringVar(value='utf-8-sig')
        ttk.Label(bar,text='C 헤더 인코딩').pack(side='left',padx=5)
        self.encoding_combo=ttk.Combobox(bar,textvariable=self.encoding,values=['utf-8-sig','cp949'],state='readonly',width=12)
        self.encoding_combo.pack(side='left')
        self.encoding_combo.bind('<<ComboboxSelected>>',lambda e:self.invalidate())

    def add(self,role):
        if self.busy:return
        if role=='common':
            p=filedialog.askopenfilename(parent=self.root,title='Common Parameter 선택',filetypes=[('Excel','*.xlsx')])
            if not p:return
            self.common=p
        else:
            types=[('C 소스/헤더','*.h *.c *.hpp *.inc'),('모든 파일','*.*')] if role=='headers' else [('Excel','*.xlsx')]
            ps=filedialog.askopenfilenames(parent=self.root,filetypes=types)
            if not ps:return
            current=getattr(self,role)
            identities={str(Path(p).resolve()).casefold() for p in current}
            current.extend(p for p in ps if str(Path(p).resolve()).casefold() not in identities)
        self.sync_inputs()
        self.invalidate()

    def remove(self,role):
        if self.busy:return
        lb=getattr(self,role+'_list')
        indexes=set(lb.curselection())
        if role=='common':
            if indexes:self.common=''
        else:setattr(self,role,[p for i,p in enumerate(getattr(self,role)) if i not in indexes])
        self.sync_inputs();self.invalidate()

    def clear(self,role):
        if self.busy:return
        if role=='common':self.common=''
        else:setattr(self,role,[])
        self.sync_inputs();self.invalidate()

    def sync_inputs(self):
        for role in ('common','headers','details'):
            lb=getattr(self,role+'_list')
            lb.delete(0,'end')
            for p in ([self.common] if role=='common' and self.common else ([] if role=='common' else getattr(self,role))):
                lb.insert('end',p)

    def build_results(self):
        bar=ttk.Frame(self.tabs[1]);bar.pack(fill='x',pady=5)
        ttk.Label(bar,text='판정 필터').pack(side='left')
        self.filter=tk.StringVar(value='전체')
        combo=ttk.Combobox(bar,textvariable=self.filter,values=['전체','MATCH','MISMATCH','REVIEW','SKIP','ERROR'],state='readonly',width=16)
        combo.pack(side='left',padx=8);combo.bind('<<ComboboxSelected>>',lambda e:self.change_page(0,reset=True))
        self.button(bar,'표시된 안전 후보 선택',self.select_visible).pack(side='left',padx=5)
        self.button(bar,'선택 해제',self.unselect).pack(side='left',padx=5)
        self.button(bar,'계산 범위 전체 내보내기',self.export).pack(side='right',padx=5)
        self.button(bar,'이전 페이지',lambda:self.change_page(-1)).pack(side='left',padx=4)
        self.button(bar,'다음 페이지',lambda:self.change_page(1)).pack(side='left',padx=4)
        self.page_label=tk.StringVar()
        ttk.Label(bar,textvariable=self.page_label).pack(side='left')
        files=ttk.LabelFrame(self.tabs[1],text='파일별 실행 상태 — 읽기 ERROR는 비트필드 REVIEW와 별도',padding=4)
        files.pack(fill='x',pady=6)
        self.file_columns=('번호','파일','Reader','읽기','실행 상태','실패 API','코드','예외 타입','시트/검색','비교','추출 변수','MATCH','MISMATCH','REVIEW','SKIP','입력 상태','저장')
        self.file_tree=ttk.Treeview(files,columns=self.file_columns,show='headings',height=5)
        for col in self.file_columns:
            self.file_tree.heading(col,text=col);self.file_tree.column(col,width=100,minwidth=45)
        self.file_tree.column('파일',width=190);self.file_tree.column('실패 API',width=170)
        self.file_tree.grid(row=0,column=0,sticky='nsew')
        fy=ttk.Scrollbar(files,orient='vertical',command=self.file_tree.yview);fy.grid(row=0,column=1,sticky='ns')
        fx=ttk.Scrollbar(files,orient='horizontal',command=self.file_tree.xview);fx.grid(row=1,column=0,sticky='ew')
        self.file_tree.configure(yscrollcommand=fy.set,xscrollcommand=fx.set)
        files.columnconfigure(0,weight=1)
        self.file_detail=tk.StringVar(value='파일별 읽기·비교 수행 여부를 확인하세요.')
        ttk.Label(files,textvariable=self.file_detail,wraplength=1180,justify='left').grid(row=2,column=0,sticky='w',pady=4)
        self.file_tree.bind('<<TreeviewSelect>>',self.show_file_status)
        cols=('선택','판정','파일','시트','셀','변수','구조체','멤버','비트폭','기존 범위','계산 범위','사유')
        frame=ttk.Frame(self.tabs[1]);frame.pack(fill='both',expand=True)
        self.tree=ttk.Treeview(frame,columns=cols,show='headings',selectmode='extended')
        for c in cols:
            self.tree.heading(c,text=c)
            self.tree.column(c,width=105 if c!='사유' else 320,minwidth=50)
        self.tree.column('선택',width=45)
        self.tree.column('비트폭',width=55)
        y=ttk.Scrollbar(frame,orient='vertical',command=self.tree.yview)
        x=ttk.Scrollbar(frame,orient='horizontal',command=self.tree.xview)
        self.tree.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        self.tree.grid(row=0,column=0,sticky='nsew');y.grid(row=0,column=1,sticky='ns');x.grid(row=1,column=0,sticky='ew')
        frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        self.tree.bind('<Button-1>',self.toggle)
        self.tree.bind('<space>',self.toggle_selected)
        self.count=tk.StringVar()
        ttk.Label(self.tabs[1],textvariable=self.count).pack(anchor='w',pady=8)

    def build_save(self):
        tab=self.tabs[2]
        self.selection_text=tk.StringVar(value='선택된 수정 항목: 0개')
        ttk.Label(tab,textvariable=self.selection_text).pack(anchor='w',pady=10)
        ttk.Label(tab,text='불일치(MISMATCH) 칸에 계산 범위를 기입합니다. 원본은 덮어쓰지 않고 출력 폴더 아래 RangeValidator_날짜시각 폴더에 같은 이름으로 저장합니다.').pack(anchor='w',pady=5)
        ttk.Label(tab,text='"비교 결과" 탭의 [계산 범위 전체 내보내기] 는 선택 없이 모든 파일의 불일치 칸을 한 번에 기입합니다. 여기서는 선택한 칸만 기입합니다.').pack(anchor='w',pady=5)
        self.output=tk.StringVar()
        row=ttk.Frame(tab);row.pack(fill='x',pady=15)
        ttk.Entry(row,textvariable=self.output,state='readonly').pack(side='left',fill='x',expand=True)
        self.button(row,'출력 폴더 선택',self.choose_output).pack(side='right',padx=5)
        row=ttk.Frame(tab);row.pack(fill='x',pady=10)
        self.button(row,'선택 수정본 및 보고서 저장',self.save).pack(side='left',padx=5)
        self.button(row,'보고서만 저장',self.report_only).pack(side='left',padx=5)
        self.save_info=tk.Text(tab,height=20,wrap='word',state='disabled')
        self.save_info.pack(fill='both',expand=True,pady=10)

    def build_logs(self):
        tab=self.tabs[3]
        self.last_diagnostics=None
        self.last_run_result=None
        self.diagnostic_window=None
        self.diagnostic_log=None
        self.log_font_size=11
        self.diagnostic_summary=tk.StringVar(value='실행 전 — 기본 마스킹 사용 / 실제 회사 DRM 미검증')
        self.diagnostic_result=tk.StringVar(value='마지막 실행 결과: 없음')
        ttk.Label(tab,textvariable=self.diagnostic_result,wraplength=1150).pack(anchor='w',pady=4)
        ttk.Label(tab,textvariable=self.diagnostic_summary,wraplength=1150,justify='left').pack(anchor='w',pady=4)
        bar=ttk.Frame(tab);bar.pack(fill='x')
        ttk.Label(bar,text='민감정보 기본 마스킹: 경로·셀 내용·원문 예외는 로그에 기록하지 않습니다.').pack(side='left')
        ttk.Button(bar,text='선택/전체 복사',command=self.copy_logs).pack(side='right',padx=4)
        self.button(bar,'로그 파일 저장 (선택)',self.export_logs).pack(side='right',padx=4)
        frame=ttk.Frame(tab);frame.pack(fill='both',expand=True,pady=8)
        self.log=tk.Text(frame,wrap='none',state='disabled',font=('맑은 고딕',self.log_font_size))
        self.log.grid(row=0,column=0,sticky='nsew')
        for orient,axis,command in [('vertical','y',self.log.yview),('horizontal','x',self.log.xview)]:
            sc=ttk.Scrollbar(frame,orient=orient,command=command)
            sc.grid(row=0 if axis=='y' else 1,column=1 if axis=='y' else 0,sticky='ns' if axis=='y' else 'ew')
            self.log.configure(**{axis+'scrollcommand':sc.set})
        frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        self.refresh_file_statuses()
        results=self.session.results if self.session else []
        visible=[(i,r) for i,r in enumerate(results) if self.filter.get() in ('전체',r.status)]
        pages=max(1,(len(visible)+self.page_size-1)//self.page_size)
        self.page=min(self.page,pages-1)
        self.page_label.set(f'{self.page+1}/{pages} 페이지')
        for i,r in visible[self.page*self.page_size:(self.page+1)*self.page_size]:
            reason=('확인 필요: ' if r.status=='REVIEW' else '')+r.reason
            self.tree.insert('', 'end',iid=str(i),values=('☑' if r.id in self.selected else '☐' if r.candidate else '',LABELS[r.status]+' ('+r.status+')',Path(r.file).name,r.sheet,r.cell,r.expression,r.struct,r.member,r.width or '',r.existing,r.expected,reason))
        from collections import Counter
        c=Counter(r.status for r in results)
        self.count.set(' / '.join(f'{LABELS[s]} {c[s]}' for s in LABELS)+f' / 파일 ERROR {sum(f.status=="ERROR" for f in getattr(self.session,"files",[]))} / 선택 {len(self.selected)}')
        self.selection_text.set(f'선택된 수정 항목: {len(self.selected)}개')
        if not self.busy:
            self.save_info.configure(state='normal');self.save_info.delete('1.0','end')
            for r in results:
                if r.id in self.selected:
                    self.save_info.insert('end',f'{Path(r.file).name} / {r.sheet}!{r.cell}: {r.existing} → {r.expected}\n')
            self.save_info.configure(state='disabled')

    def refresh_file_statuses(self):
        self.file_tree.delete(*self.file_tree.get_children())
        for i,f in enumerate(getattr(self.session,'files',[])):
            if self.filter.get()=='ERROR' and f.status!='ERROR':continue
            code=f'0x{f.code&0xffffffff:08X}' if isinstance(f.code,int) else ''
            self.file_tree.insert('','end',iid=str(i),values=(f.index,Path(f.file).name,f.reader,f.read_status,f.status,
                f.failed_api,code,f.exception_type,f'{f.sheet_index}/{f.search_phase}',
                '실행' if f.compared else '미실행',f.extracted_variables,*[f.counts[k] for k in LABELS],f.input_state,
                '차단' if f.save_blocked or f.read_status!='SUCCESS' else '안전 후보만'))

    def show_file_status(self,event=None):
        selection=self.file_tree.selection()
        if not selection or not self.session:return
        f=self.session.files[int(selection[0])]
        code=f'0x{f.code&0xffffffff:08X}' if isinstance(f.code,int) else '없음'
        self.file_detail.set(f'입력 #{f.index} | Reader {f.reader} | 읽기 {f.read_status} | {f.status} | '
            f'API {f.failed_api or "없음"} | 코드 {code} | 예외 {f.exception_type or "없음"} | '
            f'시트 #{f.sheet_index} / {f.search_phase or "검색 단계 없음"} | 비교 {"실행" if f.compared else "미실행"} | '
            f'추출 {f.extracted_variables} | 입력 {f.input_state} | 분류 {f.error_class or "해당 없음"} | {f.reason}')

    def change_page(self,delta,reset=False):
        self.page=0 if reset else max(0,self.page+delta)
        self.refresh()

    def toggle(self,event):
        if self.busy or self.tree.identify_column(event.x)!='#1':return
        item=self.tree.identify_row(event.y)
        if item:self.toggle_item(item)

    def toggle_item(self,item):
        r=self.session.results[int(item)]
        if r.candidate:
            if r.id in self.selected:self.selected.remove(r.id)
            else:self.selected.add(r.id)
            self.refresh()

    def toggle_selected(self,event):
        if not self.busy and self.session:
            for item in self.tree.selection():self.toggle_item(item)
        return 'break'

    def select_visible(self):
        if self.busy or not self.session:return
        self.selected.update(self.session.results[int(i)].id for i in self.tree.get_children() if self.session.results[int(i)].candidate)
        self.refresh()

    def unselect(self):
        if self.busy:return
        self.selected.clear();self.refresh()

    def choose_output(self):
        p=filedialog.askdirectory(parent=self.root,title='출력 폴더 선택')
        if p:self.output.set(p)

    def start(self,func,kind):
        if self.busy:return
        self.busy=True
        for c in self.controls:c.configure(state='disabled')
        self.encoding_combo.configure(state='disabled')
        self.progress.start(12)
        def work():
            try:self.queue.put(('done',kind,func()))
            except Exception as exc:self.queue.put(('error',kind,exc))
        threading.Thread(target=work,name='RangeValidator-STA',daemon=False).start()

    def progress_event(self,i,n,name):
        self.queue.put(('progress',i,n,name))

    def compare(self):
        if not self.headers or not self.details:
            messagebox.showinfo('파일 등록','C 헤더와 상세설계서는 등록해야 합니다. Common Parameter는 선택 사항입니다.',parent=self.root);return
        self.invalidate()
        diag=Diagnostics(lambda e:self.queue.put(('log',e)))
        self.last_diagnostics=diag
        self.diagnostic_summary.set('현재 실행 ID: '+diag.run_id+' — 읽기 진행 중')
        common,headers,details=self.common,list(self.headers),list(self.details)
        encoding=self.encoding.get()
        self.start(lambda:run_comparison(common,headers,details,diagnostics=diag,encoding=encoding,progress=self.progress_event),'compare')

    def save(self):
        if not self.session or not self.selected or not self.output.get():
            messagebox.showinfo('수정 및 저장','안전한 수정 후보와 출력 폴더를 선택하세요.',parent=self.root);return
        records={f.file:f for f in getattr(self.session,'files',[])}
        chosen=[r for r in self.session.results if r.id in self.selected]
        if len(chosen)!=len(self.selected) or any(not r.candidate or (r.file in records and (records[r.file].status=='ERROR' or records[r.file].read_status!='SUCCESS' or records[r.file].save_blocked)) for r in chosen):
            messagebox.showerror('저장 차단','읽기 실패·입력 상태 불확실·안전하지 않은 대상은 저장할 수 없습니다.',parent=self.root)
            return
        if not messagebox.askyesno('선택 항목 확인',f'선택한 {len(self.selected)}개 항목을 새 파일에 저장하시겠습니까?\n원본은 변경하지 않습니다.',parent=self.root):return
        session,selected,parent=self.session,set(self.selected),self.output.get()
        self.start(lambda:save_selected(session,selected,parent,self.progress_event),'save')

    def export(self):
        """모든 상세설계서의 불일치(MISMATCH) 칸에 계산 범위를 기입해 새 폴더로 저장"""
        if self.busy or not self.session:
            messagebox.showinfo('내보내기','먼저 비교를 실행하세요.',parent=self.root);return
        n=sum(1 for r in self.session.results if r.status=='MISMATCH' and r.candidate)
        files=len({r.file for r in self.session.results if r.status=='MISMATCH' and r.candidate})
        if not n:
            messagebox.showinfo('내보내기','계산 범위와 다른 칸(불일치)이 없습니다. 내보낼 파일이 없습니다.',parent=self.root);return
        p=filedialog.askdirectory(parent=self.root,title='내보낼 폴더 선택 (하위에 RangeValidator_날짜시각 폴더를 만듭니다)')
        if not p:return
        if not messagebox.askyesno('전체 내보내기',f'상세설계서 {files}개 파일의 {n}개 칸에 계산 범위를 기입해 새 파일로 저장합니다.\n원본은 변경하지 않습니다. 진행할까요?',parent=self.root):return
        self.output.set(p)
        session=self.session
        self.start(lambda:export_all(session,p,self.progress_event),'save')

    def report_only(self):
        if not self.session:return
        path=filedialog.asksaveasfilename(parent=self.root,initialfile='RangeValidator_Report.xlsx',defaultextension='.xlsx',filetypes=[('Excel','*.xlsx')])
        if not path:return
        self.start(lambda:create_report(self.session,self.outcomes,path),'report')

    def on_destroy(self,event):
        if event.widget is self.root:
            try:self.root.after_cancel(self.after_id)
            except tk.TclError:pass

    def drain(self):
        try:self.root.after_cancel(self.after_id)
        except tk.TclError:pass
        try:
            for _ in range(250):
                event=self.queue.get_nowait()
                kind=event[0]
                if kind=='log':
                    e=event[1]
                    self.append_diagnostic(format_event(e))
                    if e.status=='FAILED':
                        self.diagnostic_summary.set(f'실행 ID: {e.run_id} | 실패 API: {e.api or e.stage} | 입력 {e.input_role} #{e.file_index} / 시트 #{e.sheet_index} / {e.search_phase} | 예외: {e.exception_type or "없음"} | 분류: {e.error_class or "해당 없음"} | HRESULT: {e.hresult or "없음"} | Win32: {e.win32_code}\n마지막 성공: {e.last_success or "없음"} | Open 진입: {"예" if e.open_entered else "아니오"}')
                        self.show_diagnostics()
                    elif e.stage=='com.process.exit':
                        self.diagnostic_summary.set(self.diagnostic_summary.get().split('\nExcel 종료:')[0]+'\nExcel 종료: '+('성공' if e.status=='OK' else '확인 필요'))
                    elif e.stage in ('openpyxl.complete','com.complete') and e.status=='OK':
                        self.diagnostic_summary.set(f'실행 ID: {e.run_id} | Reader: {e.reader} | 읽기 성공 | 마지막 성공: {e.last_success} | Excel 종료: {e.excel_exit or "해당 없음"}')
                elif kind=='progress':
                    self.status.set(f'처리 중 {event[1]}/{event[2]} — {event[3]}')
                else:
                    self.busy=False
                    self.progress.stop()
                    self.encoding_combo.configure(state='readonly')
                    for c in self.controls:c.configure(state='normal')
                    if kind=='error':
                        exc=event[2]
                        stage=getattr(exc,'stage','작업 검증')
                        self.status.set(f'확인 필요 — {stage} / 코드 {getattr(exc,"code",None)}')
                        self.notebook.select(self.tabs[3])
                        self.last_run_result={'operation':event[1],'status':'FAILED','stage':stage if stage in STAGES else 'gui.run','code':getattr(exc,'code',None)}
                        self.diagnostic_result.set('마지막 실행 결과: 실패 — '+self.last_run_result['stage'])
                        self.show_diagnostics()
                        if event[1]!='compare':
                            messagebox.showerror('작업 중단','입력 변경 또는 읽기/저장/안전 조건을 확인할 수 없어 작업을 중단했습니다. 진단 로그를 확인하세요.',parent=self.root)
                    elif event[1]=='compare':
                        files=getattr(event[2],'files',[])
                        errors=sum(f.status=='ERROR' for f in files)
                        unavailable=sum(f.input_state!='STABLE' for f in files)
                        self.last_run_result={'operation':'compare','status':'PARTIAL_ERROR' if errors else 'INPUT_STATE_BLOCKED' if unavailable else 'COMPLETED',
                            'file_errors':errors,'read_errors':sum(f.read_status=='FAILED' for f in files),'input_state_issues':unavailable}
                        self.diagnostic_result.set(f'마지막 실행 결과: 파일 ERROR {errors} / 입력 상태 확인 필요 {unavailable} — 파일별 표와 로그 확인')
                        cs=getattr(event[2],'catalog_summary',{}) or {}
                        self.session=event[2];self.refresh()
                        self.status.set(f"비교 완료 — C 소스 {cs.get('files',0)}개: 구조체 {cs.get('structs',0)} / 비트필드 {cs.get('bitfields',0)} (범위 확정 {cs.get('certified',0)}) / 변수 {cs.get('variables',0)} / typedef {cs.get('typedefs',0)} | 파일 ERROR {errors} / 입력 상태 확인 {unavailable}")
                        if not any(e.status=='FAILED' for e in self.session.diagnostics.events):self.notebook.select(self.tabs[1])
                    elif event[1]=='save':
                        folder,self.outcomes=event[2]
                        saved=sum(v['status']=='SAVED' for v in self.outcomes.values());failed=sum(v['status']!='SAVED' for v in self.outcomes.values())
                        nfiles=len({v['output'] for v in self.outcomes.values() if v['status']=='SAVED'})
                        self.status.set(f'저장 결과: 파일 {nfiles}개 / 칸 {saved}개 기입, 실패 {failed}개 → {folder}')
                        lines=[str(folder),self.status.get(),'']+sorted({f"{Path(v['file']).name}: {v['reason']}" for v in self.outcomes.values()})
                        self.save_info.configure(state='normal');self.save_info.delete('1.0','end');self.save_info.insert('end','\n'.join(lines));self.save_info.configure(state='disabled')
                        self.notebook.select(self.tabs[2])
                    else:self.status.set('보고서 저장 완료')
                    if self.closing:
                        self.root.destroy();return
        except queue.Empty:pass
        self.after_id=self.root.after(100,self.drain)

    def append_diagnostic(self,text):
        for widget in (self.log,self.diagnostic_log):
            if widget is not None and widget.winfo_exists():
                widget.configure(state='normal')
                widget.insert('end',text)
                if int(widget.index('end-1c').split('.')[0])>5000:widget.delete('1.0','1001.0')
                widget.see('end')
                widget.configure(state='disabled')

    def show_diagnostics(self):
        self.notebook.select(self.tabs[3])
        if self.diagnostic_window is not None and self.diagnostic_window.winfo_exists():
            self.diagnostic_window.deiconify();self.diagnostic_window.lift();return
        win=tk.Toplevel(self.root)
        self.diagnostic_window=win
        win.title('RangeValidator — 진단 로그 보기 (기본 마스킹)')
        win.geometry('1120x720');win.minsize(800,480)
        ttk.Label(win,textvariable=self.diagnostic_result,wraplength=1050,justify='left').pack(anchor='w',padx=12,pady=5)
        ttk.Label(win,textvariable=self.diagnostic_summary,wraplength=1050,justify='left').pack(anchor='w',padx=12,pady=5)
        bar=ttk.Frame(win);bar.pack(fill='x',padx=10,pady=5)
        ttk.Button(bar,text='복사',command=self.copy_logs).pack(side='left',padx=4)
        ttk.Button(bar,text='글자 크게',command=lambda:self.zoom_logs(1)).pack(side='left',padx=4)
        ttk.Button(bar,text='글자 작게',command=lambda:self.zoom_logs(-1)).pack(side='left',padx=4)
        ttk.Label(bar,text='경로·파일명·셀 값·원문 오류 생략 / 창 크기 조절 후 화면 촬영 가능').pack(side='left',padx=8)
        frame=ttk.Frame(win);frame.pack(fill='both',expand=True,padx=10,pady=(0,10))
        log=tk.Text(frame,wrap='none',font=('맑은 고딕',self.log_font_size))
        log.grid(row=0,column=0,sticky='nsew')
        self.diagnostic_log=log
        log.insert('end',self.log.get('1.0','end-1c'));log.configure(state='disabled')
        for orient,axis,command in [('vertical','y',log.yview),('horizontal','x',log.xview)]:
            scroll=ttk.Scrollbar(frame,orient=orient,command=command)
            scroll.grid(row=0 if axis=='y' else 1,column=1 if axis=='y' else 0,sticky='ns' if axis=='y' else 'ew')
            log.configure(**{axis+'scrollcommand':scroll.set})
        frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)

    def zoom_logs(self,delta):
        self.log_font_size=max(9,min(20,self.log_font_size+delta))
        for widget in (self.log,self.diagnostic_log):
            if widget is not None and widget.winfo_exists():widget.configure(font=('맑은 고딕',self.log_font_size))

    def copy_logs(self):
        widget=self.diagnostic_log if self.diagnostic_log is not None and self.diagnostic_log.winfo_exists() else self.log
        try:data=widget.get('sel.first','sel.last')
        except tk.TclError:data=widget.get('1.0','end')
        self.root.clipboard_clear();self.root.clipboard_append(data)

    def export_logs(self):
        p=filedialog.asksaveasfilename(parent=self.root,defaultextension='.log',filetypes=[('로그','*.log')])
        if p:
            try:
                with open(p,'x',encoding='utf-8') as f:f.write(self.log.get('1.0','end'))
            except OSError:messagebox.showerror('로그 저장','기존 파일 또는 접근 권한을 확인하세요.',parent=self.root)

    def close(self):
        if self.busy:
            self.closing=True
            self.status.set('작업 및 Excel 정리 후 종료합니다. 잠시 기다려 주세요.')
        else:self.root.destroy()


def main():
    root=tk.Tk()
    App(root)
    root.mainloop()

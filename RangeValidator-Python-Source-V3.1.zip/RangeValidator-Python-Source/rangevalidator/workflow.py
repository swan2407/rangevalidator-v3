"""Per-input evidence and per-file execution states; keep comparison snapshots intact."""
from collections import Counter
from dataclasses import dataclass, field, replace, asdict
import hashlib
import json
import os
from pathlib import Path
import uuid
from .common import parse_common
from .diagnostics import Diagnostics
from .engine import catalog_headers, compare_book
from .readers import read_auto, read_workbook, read_com
from .models import ReadFailure


class InputUnstableError(RuntimeError):
    pass


def source_path(path):
    try:return str(Path(path).resolve())
    except OSError:return os.path.abspath(os.fspath(path))


def canonical(path):
    return os.path.normcase(source_path(path))


def fingerprint(path):
    p=Path(path);before=p.stat();h=hashlib.sha256()
    with p.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    after=p.stat()
    if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
        raise InputUnstableError('Input state unstable while hashing')
    return h.hexdigest(),after.st_size,after.st_mtime_ns


def observe(path):
    try:return dict(stamp=fingerprint(path),code=None,exception_type='',reason='')
    except Exception as exc:
        failure=ReadFailure('input.fingerprint',exc)
        return dict(stamp=None,code=failure.code,
                    exception_type=type(exc).__module__+'.'+type(exc).__qualname__,
                    reason='UNSTABLE_DURING_HASH' if isinstance(exc,InputUnstableError) else 'STATE_QUERY_FAILED')


def check_observations(before,after):
    """Input stability between two observations.
    V3.1: a hash-only change (same size, same mtime) is treated as STABLE. Company DRM agents rewrite the
    protected container (access log / re-wrap) when Excel opens the file, which changes the byte hash while
    the document content, size and mtime stay the same. A real edit always changes mtime (and usually size)."""
    record=dict(status='STABLE',hash_changed=None,size_changed=None,mtime_changed=None,
                code=after['code'],exception_type=after['exception_type'],reason=after['reason'])
    if before['stamp'] is None or after['stamp'] is None:
        record.update(status='STATE_UNAVAILABLE',reason=before['reason'] or after['reason'] or 'MISSING_BASELINE',
                      code=after['code'] if after['stamp'] is None else before['code'],
                      exception_type=after['exception_type'] if after['stamp'] is None else before['exception_type'])
        return record
    record.update(zip(('hash_changed','size_changed','mtime_changed'),(a!=b for a,b in zip(before['stamp'],after['stamp']))))
    if record['size_changed'] or (record['hash_changed'] and record['mtime_changed']):record['status']='CONTENT_CHANGED'
    elif record['mtime_changed']:record['status']='METADATA_CHANGED'
    elif record['hash_changed']:record['reason']='HASH_ONLY_CHANGE (DRM 컨테이너 갱신으로 보고 STABLE 처리)'
    return record


def same_stamp(a,b):
    """Stamp equality for the Writer: size and mtime must match; hash may differ (DRM re-wrap)."""
    return a is not None and b is not None and a[1]==b[1] and a[2]==b[2]


@dataclass
class FileStatus:
    index: int
    file: str
    reader: str = 'unknown'
    read_status: str = 'NOT_ATTEMPTED'
    status: str = 'PENDING'
    error_kind: str = ''
    failed_api: str = ''
    failed_stage: str = ''
    code: int | None = None
    exception_type: str = ''
    error_class: str = ''
    sheet_index: int = 0
    search_phase: str = ''
    compared: bool = False
    extracted_variables: int = 0
    counts: dict = field(default_factory=lambda:{s:0 for s in ('MATCH','MISMATCH','REVIEW','SKIP')})
    input_state: str = 'STABLE'
    save_blocked: bool = True
    reason: str = ''
    partial: bool = False


@dataclass
class Session:
    common_path: str
    headers: tuple[str,...]
    details: tuple[str,...]
    backend: str = 'auto'
    encoding: str = 'utf-8-sig'
    id: str = field(default_factory=lambda:uuid.uuid4().hex)
    results: list = field(default_factory=list)
    coverage: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    stamps: dict = field(default_factory=dict)
    readers: dict = field(default_factory=dict)
    diagnostics: object = None
    books: dict = field(default_factory=dict,repr=False)
    files: list[FileStatus] = field(default_factory=list)
    input_checks: dict = field(default_factory=dict)
    catalog_summary: dict = field(default_factory=dict)
    _signature: str = ''

    def signature(self):
        payload=dict(inputs=[self.common_path,self.headers,self.details,self.backend,self.encoding],
                     stamps=self.stamps,results=[asdict(r) for r in self.results],
                     files=[asdict(f) for f in self.files],input_checks=self.input_checks)
        return hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

    def assert_unchanged(self):
        if self._signature!=self.signature():raise RuntimeError('REVIEW: analysis session was changed; compare again')
        if any(c['status']!='STABLE' for c in self.input_checks.values()):
            raise RuntimeError('INPUT_STATE_BLOCKED: changed or unavailable input evidence; compare again')
        expected=[p for p in [self.common_path,*self.headers,*self.details] if p]
        if len(self.stamps)!=len(set(expected)):
            raise RuntimeError('INPUT_STATE_UNAVAILABLE: complete input fingerprints required')
        for path,stamp in self.stamps.items():
            current=observe(path)
            checked=check_observations(dict(stamp=stamp,code=None,exception_type='',reason=''),current)
            if checked['status']!='STABLE':raise RuntimeError('INPUT_'+checked['status']+': saving blocked; compare again')


def _run_comparison(common_path,headers,details,backend='auto',encoding='utf-8-sig',diagnostics=None,progress=None):
    diag=diagnostics or Diagnostics()
    hdr=tuple(dict.fromkeys(source_path(p) for p in headers));det=tuple(dict.fromkeys(source_path(p) for p in details))
    common_path=source_path(common_path) if common_path else ''
    s=Session(common_path,hdr,det,backend,encoding,diagnostics=diag)
    allpaths=[p for p in [s.common_path,*hdr,*det] if p]
    if len({canonical(p) for p in allpaths})!=len(allpaths):raise ValueError('Input roles contain duplicate files')
    s.files=[FileStatus(i,p) for i,p in enumerate(det,1)]
    roles=({s.common_path:('common',1)} if s.common_path else {}) | {p:('header',i) for i,p in enumerate(hdr,1)} | {p:('detail',i) for i,p in enumerate(det,1)}
    def context(path):
        role,index=roles[path];diag.set_context(input_role=role,file_index=index,sheet_index=0,row=0,column=0,sheet_name='')
    before={}
    for path in allpaths:
        context(path);before[path]=observe(path)
        if before[path]['stamp'] is not None:s.stamps[path]=before[path]['stamp']
        else:diag.emit('native','input.fingerprint.before','FAILED',before[path]['code'],exception_type=before[path]['exception_type'],message='STATE_UNAVAILABLE')
    def read(path):
        context(path)
        if backend=='auto':book=read_auto(path,diagnostics=diag)
        elif backend=='com':book=read_com(path,_trace=diag)
        else:
            book=read_workbook(path,backend);diag.emit(backend,'read.complete','OK')
        s.readers[path]=book.backend;s.books[path]=book
        return book
    def error(path,exc,kind):
        code=getattr(exc,'code',None)
        if code is None:code=ReadFailure('detail.read',exc).code
        stage=getattr(exc,'stage','detail.read');api=getattr(exc,'api',stage)
        typename=getattr(exc,'exception_type',type(exc).__module__+'.'+type(exc).__qualname__)
        if stage=='cleanup' and getattr(exc,'cleanup_errors',None):
            first=exc.cleanup_errors[0];stage=first['stage'];api=first.get('api',stage);code=first.get('code');typename=first.get('exception_type',typename)
        ctx=getattr(exc,'context',{})
        from .error_info import classify_error
        item=dict(file=path,stage=stage,api=api,code=code,exception_type=typename,error_class=getattr(exc,'error_class',classify_error(code,typename)),error_kind=kind,
                  file_index=roles[path][1],sheet_index=ctx.get('sheet_index',0),search_phase=ctx.get('search_phase',''),
                  reason=kind+': see file execution status; DRM status unknown')
        s.errors.append(item)
        return item
    common=None
    if s.common_path:
        try:common=parse_common(read(s.common_path))
        except Exception as exc:error(s.common_path,exc,'COMMON_READ_ERROR')
    diag.set_context(input_role='header',file_index=0,sheet_index=0,row=0,column=0,sheet_name='')
    catalog=catalog_headers(hdr,encoding,diag)
    s.catalog_summary=dict(files=len(catalog.files),structs=len(catalog.types),bitfields=sum(len(t.fields) for t in catalog.types),
                           certified=sum(1 for t in catalog.types for f in t.fields if f.minimum is not None),
                           variables=len(catalog.variables),typedefs=len(catalog.typedefs),macros=len(catalog.macros),reviews=list(catalog.reviews))
    try:common_root=Path(os.path.commonpath([str(Path(p).parent) for p in det])) if det else None
    except ValueError:common_root=None
    for i,path in enumerate(det):
        record=s.files[i]
        if progress:progress(i,len(det),Path(path).name)
        try:
            book=read(path);record.read_status='SUCCESS';record.reader=book.backend
        except Exception as exc:
            record.reader=getattr(exc,'backend','') or ('com' if str(getattr(exc,'stage','')).startswith('com.') else backend)
            s.readers[path]=record.reader
            item=error(path,exc,'READ_ERROR');record.read_status='FAILED';record.status='ERROR';record.error_kind='READ_ERROR'
            for attr,k in (('failed_api','api'),('failed_stage','stage'),('code','code'),('exception_type','exception_type'),('error_class','error_class'),('sheet_index','sheet_index'),('search_phase','search_phase')):setattr(record,attr,item[k])
            record.reason='Document read failed; comparison not performed'
            continue
        if common is None and s.common_path:
            record.status='ERROR';record.error_kind='DEPENDENCY_ERROR';record.failed_api='common.read'
            record.reason='Common workbook unavailable; comparison not performed';continue
        try:
            relative=str(Path(path).relative_to(common_root)) if common_root else Path(path).name
            result,coverage=compare_book(common,catalog,book,relative)
            result_start=len(s.results)
            s.results.extend(result);s.coverage.extend((path,*r) for r in coverage)
            if diag:
                sheet_numbers={sheet.name:i for i,sheet in enumerate(book.sheets,1)}
                for r in result:
                    if r.status=='REVIEW':
                        diag.set_context(input_role='detail',file_index=record.index,
                                         sheet_index=sheet_numbers.get(r.sheet,0),sheet_name=r.sheet)
                        diag.emit('native','comparison.result','OK',decision='REVIEW',
                                  cell_address=r.cell,detail=r.reason)
            record.status='COMPLETED'
            record.partial=bool(book.partial)
            if book.partial:
                record.status='PARTIAL'
                record.error_kind='PARTIAL_READ'
                record.reason='PARTIAL_READ: one or more sheets failed; available sheets compared; saving blocked'
                for item in book.read_errors:
                    s.errors.append(dict(file=path,**item,error_kind='SHEET_READ_ERROR',file_index=record.index,reason='SHEET_READ_ERROR: sheet omitted; workbook is incomplete'))
            record.extracted_variables=sum(bool(r.cell and r.expression) for r in result)
            record.compared=bool(record.extracted_variables)
            record.counts={status:sum(r.status==status for r in result) for status in record.counts}
            headers_only=not bool(s.common_path)
            record.save_blocked=record.partial or not any(r.candidate for r in result)
            if headers_only:
                record.reason='C 소스 기준 비교 완료 (Common Parameter 미사용)'
            if record.partial:
                s.results=[replace(r,candidate=False,reason=r.reason+'; PARTIAL_READ: workbook is incomplete') if result_start <= ix < result_start+len(result) else r for ix,r in enumerate(s.results)]
            if not record.extracted_variables:
                record.status='NO_VARIABLES';record.reason='NO_VARIABLES: no variable comparison performed'
        except Exception as exc:
            item=error(path,exc,'COMPARISON_ERROR');record.status='ERROR';record.error_kind='COMPARISON_ERROR'
            record.failed_stage='comparison.run';record.failed_api='comparison.run';record.code=item['code'];record.exception_type=item['exception_type']
            record.reason='Comparison failed; no result rows committed'
            diag.set_context(input_role='detail',file_index=record.index,sheet_index=item.get('sheet_index',0))
            diag.emit('native','comparison.result','OK',decision='ERROR',detail=record.reason)
    for path in allpaths:
        context(path);checked=check_observations(before[path],observe(path));s.input_checks[path]=checked
        diag.emit('native','input.fingerprint.after','OK' if checked['status']=='STABLE' else 'FAILED',checked['code'],
                  exception_type=checked['exception_type'],message=checked['status'],hash_changed=checked['hash_changed'],size_changed=checked['size_changed'],mtime_changed=checked['mtime_changed'])
    dependency_bad=[p for p in ([s.common_path] if s.common_path else [])+list(hdr) if s.input_checks[p]['status']!='STABLE']
    for record in s.files:
        affected=dependency_bad+([record.file] if s.input_checks[record.file]['status']!='STABLE' else [])
        if affected:
            states={s.input_checks[p]['status'] for p in affected}
            record.input_state=next(x for x in ('CONTENT_CHANGED','STATE_UNAVAILABLE','METADATA_CHANGED') if x in states)
            record.save_blocked=True
            if record.status!='ERROR':record.status='INPUT_'+record.input_state
            evidence='; '.join(f'{roles[p][0]} #{roles[p][1]} hash_changed={s.input_checks[p]["hash_changed"]},size_changed={s.input_checks[p]["size_changed"]},mtime_changed={s.input_checks[p]["mtime_changed"]}' for p in affected)
            suffix='INPUT_'+record.input_state+': comparison snapshot retained; saving blocked; '+evidence
            record.reason=(record.reason+'; ' if record.reason else '')+suffix
            s.results=[replace(r,candidate=False,reason=r.reason+'; '+suffix) if r.file==record.file else r for r in s.results]
    # The existing Writer validates/locks every registered input. Keep that conservative
    # session-wide save gate, without rewriting any comparison classification/evidence.
    if any(c['status']!='STABLE' for c in s.input_checks.values()):
        for record in s.files:
            if not record.save_blocked:
                record.save_blocked=True
                record.reason=(record.reason+'; ' if record.reason else '')+'SESSION_SAVE_BLOCKED: another input has changed/unavailable evidence'
        s.results=[replace(r,candidate=False,reason=r.reason+'; SESSION_SAVE_BLOCKED: input evidence incomplete') if r.candidate else r for r in s.results]
    if progress:progress(len(det),len(det),'완료')
    s._signature=s.signature()
    return s


def run_comparison(common_path, headers, details, backend='auto', encoding='utf-8-sig', diagnostics=None, progress=None):
    from .com_values import excel_session
    with excel_session(diagnostics):
        return _run_comparison(common_path, headers, details, backend, encoding, diagnostics, progress)

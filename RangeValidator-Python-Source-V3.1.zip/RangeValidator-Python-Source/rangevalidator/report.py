﻿"""Fresh, no-overwrite XLSX report, with literal text to prevent formula injection."""
from collections import Counter
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

HEADERS = ['File','Sheet','Cell','Variable','Struct','Member','Bit width','Signed','Calculated Range','Existing Range','Decision','Write result','Reason','Source','Source line','Common sheet','Common row','Common File','Reader']


def literal(ws,row,values):
    for col,v in enumerate(values,1):
        c = ws.cell(row,col)
        if isinstance(v,str):
            c.value = v[:32767]
            c.data_type = 's'
        else:
            c.value = v


def create_report(session,outcomes,path):
    p = Path(path)
    p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():
        raise FileExistsError('Report already exists')
    w = Workbook()
    w.active.title = 'Summary'
    for name in ('Changes','Review','Errors','Results'):
        w.create_sheet(name)
    counts = Counter(r.status for r in session.results)
    for row,pair in enumerate([('Run ID',session.id),('Writer','수정 칸만 Excel 로 기입 후 SaveAs; 저장본 재확인'),*sorted(counts.items()),('Input failures',len(session.errors))],1):
        literal(w['Summary'],row,pair)
    for name in ('Changes','Review','Results'):
        literal(w[name],1,HEADERS)
    for r in session.results:
        outcome = outcomes.get(r.id, {})
        state = outcome.get('status','NOT_SELECTED' if r.candidate else 'NOT_APPLICABLE')
        vals = [r.file,r.sheet,r.cell,r.expression,r.struct,r.member,r.width,r.signed,r.expected,r.existing,r.status,state,
                outcome.get('reason',r.reason),r.source,r.source_line,r.common_sheet,r.common_row,r.common_file,r.backend]
        literal(w['Results'],w['Results'].max_row+1,vals)
        if state in ('SAVED','VERIFIED','DRM_CONFIRM_REQUIRED','PRESERVATION_REVIEW'):
            literal(w['Changes'],w['Changes'].max_row+1,vals)
        if r.status == 'REVIEW' or (r.status == 'MISMATCH' and state not in ('SAVED','VERIFIED')):
            literal(w['Review'],w['Review'].max_row+1,vals)
    literal(w['Errors'],1,['File','Stage','Code','Status','Reason'])
    for e in session.errors:
        literal(w['Errors'],w['Errors'].max_row+1,[e.get(k,'') for k in ('file','stage','code','status','reason')])
    for outcome in outcomes.values():
        if outcome.get('status') in ('FAILED','REVIEW','PRESERVATION_REVIEW'):
            literal(w['Errors'],w['Errors'].max_row+1,[outcome.get('file',''),outcome.get('stage',''),outcome.get('code'),outcome.get('status'),outcome.get('reason')])
    for ws in w.worksheets:
        ws.freeze_panes='A2'
        ws.auto_filter.ref=ws.dimensions
        for c in ws[1]:
            c.font=Font(bold=True,color='FFFFFF')
            c.fill=PatternFill('solid',fgColor='24496B')
        for column in ws.columns:
            ws.column_dimensions[column[0].column_letter].width = 24
        for row in ws:
            for c in row:
                c.alignment=Alignment(vertical='top',wrap_text=True)
    with p.open('xb') as stream:
        w.save(stream)
    w.close()
    return p

"""Selected certified MISMATCH only. Excel is the only detailed-document Writer."""
from contextlib import contextmanager
import gc
import os
from pathlib import Path
import uuid
import zipfile
from .workflow import fingerprint, canonical, same_stamp
from .readers import Win32Runtime, read_com, _com_bounds
from .preservation import manifest, verify
from .report import create_report
from .models import ReadFailure


@contextmanager
def input_locks(paths):
    import win32file
    handles = []
    try:
        for path in paths:
            handles.append(win32file.CreateFile(str(path),win32file.GENERIC_READ,
                win32file.FILE_SHARE_READ,None,win32file.OPEN_EXISTING,win32file.FILE_ATTRIBUTE_NORMAL,None))
        yield
    finally:
        for h in reversed(handles):
            h.Close()


@contextmanager
def excel_book(path,diag):
    runtime = Win32Runtime()
    app = books = book = None
    initialized = owned = False
    pid = None
    stage = 'com.STA.initialize'
    errors = []
    primary = None
    def mark(s):
        nonlocal stage
        stage=s
        diag.emit('COM',s)
    try:
        mark(stage)
        runtime.initialize()
        initialized = True
        before = runtime.process_ids()
        mark('com.DispatchEx')
        app = runtime.dispatch()
        mark('com.instance.verify')
        pid = runtime.pid(app)
        if not pid or pid in before:
            raise RuntimeError('Cannot prove new Excel ownership')
        owned = True
        mark('com.security')
        app.Visible=False
        app.DisplayAlerts=False
        app.ScreenUpdating=False
        app.EnableEvents=False
        app.AskToUpdateLinks=False
        app.AutomationSecurity=3
        books=app.Workbooks
        mark('com.Workbooks.Open')
        book=books.Open(Filename=str(Path(path).resolve()),UpdateLinks=0,ReadOnly=True,
            IgnoreReadOnlyRecommended=True,Notify=False,AddToMru=False,Password='',WriteResPassword='')
        if not book.ReadOnly:
            raise RuntimeError('Workbook did not open ReadOnly')
        yield book,mark
    except Exception as exc:
        primary = exc if isinstance(exc,ReadFailure) else ReadFailure(stage,exc)
        diag.emit('COM',primary.stage,'FAILED',primary.code)
    finally:
        if book is not None:
            try:
                book.Close(SaveChanges=False)
            except Exception as exc:
                errors.append(ReadFailure('com.Close(False)',exc).as_dict())
        book=books=None
        if app is not None and owned:
            try:
                app.Quit()
            except Exception as exc:
                errors.append(ReadFailure('com.Quit',exc).as_dict())
        app=None
        gc.collect()
        if initialized:
            runtime.uninitialize()
        if owned:
            try:
                runtime.wait_exit(pid)
                diag.emit('COM','com.process.exit','OK')
            except Exception as exc:
                errors.append(ReadFailure('com.process.exit',exc).as_dict())
                diag.emit('COM','com.process.exit','FAILED')
    if primary or errors:
        err=primary or ReadFailure('cleanup',RuntimeError('Excel cleanup failed'))
        err.cleanup_errors.extend(errors)
        raise err




def com_manifest(book):
    """In-memory COM-only preservation evidence; no decrypted workbook copy.
    Image bytes/formatting wholly outside Find bounds cannot be certified here.
    """
    from .models import address
    result=dict(sheets=[],media=None,charts=[])
    total=0
    ws=cell=area=comment=links=None
    try:
        sheets=book.Worksheets
        if sheets.Count>512:
            raise ValueError('Sheet preservation budget exceeded')
        for index in range(1,sheets.Count+1):
            ws=sheets.Item(index)
            bounds=_com_bounds(ws)
            cells={};merges=set()
            if bounds:
                r1,c1,r2,c2=bounds
                total+=(r2-r1+1)*(c2-c1+1)
                if total>250000:
                    raise ValueError('COM preservation cell budget exceeded')
                for row in range(r1,r2+1):
                    for col in range(c1,c2+1):
                        cell=ws.Cells.Item(row,col)
                        v=cell.Formula if cell.HasFormula else cell.Value2
                        if cell.MergeCells:
                            area=cell.MergeArea
                            merges.add(str(area.Address).replace('$',''))
                            area=None
                        note=None
                        comment=cell.Comment
                        if comment is not None:
                            note=(comment.Text(),comment.Author)
                        comment=None
                        link=None
                        links=cell.Hyperlinks
                        if links.Count:
                            h=links.Item(1)
                            link=(h.Address,h.SubAddress)
                            h=None
                        links=None
                        cells[address(row,col)]=(v,None,link,note)
                        cell=None
            result['sheets'].append(dict(name=str(ws.Name),state=ws.Visible,cells=cells,rows={},columns={},
                merges=sorted(merges),freeze='',autofilter='',images=ws.Shapes.Count,charts=0,shapes=None))
            ws=None
        return result
    finally:
        links=comment=area=cell=ws=sheets=None

def effective_formats(book, native):
    """Excel-rendered format values, avoiding locale/theme XML serialization artifacts."""
    result={}
    ws=cell=font=interior=borders=border=None
    try:
        for sheet in native['sheets']:
            ws=book.Worksheets.Item(sheet['name'])
            shapes=[]
            collection=shape=None
            try:
                collection=ws.Shapes
                for i in range(1,collection.Count+1):
                    shape=collection.Item(i)
                    if shape.Type!=13:
                        raise ValueError('Non-picture drawing object requires preservation review')
                    shapes.append((shape.Name,shape.Type,*[round(float(getattr(shape,p)),3) for p in ('Left','Top','Width','Height','Rotation')],shape.Placement,bool(shape.Visible)))
                    shape=None
            finally:
                shape=collection=None
            result[('shapes',sheet['name'])]=shapes
            from openpyxl.utils.cell import coordinate_from_string,column_index_from_string
            positions=[coordinate_from_string(a) for a in sheet['cells']]
            row_ids={r for _,r in positions}|set(sheet['rows'])
            col_ids={column_index_from_string(c) for c,_ in positions}|set(sheet['columns'])
            dimensions={}
            for r in row_ids:
                cell=ws.Rows.Item(r)
                dimensions[r]=(cell.RowHeight,bool(cell.Hidden),cell.OutlineLevel)
                cell=None
            result[('rows',sheet['name'])]=dimensions
            dimensions={}
            for col in col_ids:
                cell=ws.Columns.Item(col)
                dimensions[col]=(cell.ColumnWidth,bool(cell.Hidden),cell.OutlineLevel)
                cell=None
            result[('columns',sheet['name'])]=dimensions
            for a in sheet['cells']:
                cell=ws.Range(a)
                font=cell.Font
                interior=cell.Interior
                borders=cell.Borders
                edges=[]
                for i in (7,8,9,10,11,12):
                    border=borders.Item(i)
                    line=border.LineStyle
                    edges.append((line,border.Weight,border.Color) if line!=-4142 else (line,))
                    border=None
                result[(sheet['name'],a)]=(font.Name,font.Size,bool(font.Bold),bool(font.Italic),font.Underline,
                    bool(font.Strikethrough),font.Color,interior.Pattern,interior.Color,interior.PatternColor,
                    cell.NumberFormat,cell.HorizontalAlignment,cell.VerticalAlignment,bool(cell.WrapText),
                    cell.Orientation,cell.IndentLevel,bool(cell.ShrinkToFit),bool(cell.Locked),bool(cell.FormulaHidden),tuple(edges))
                borders=interior=font=cell=None
            ws=None
    finally:
        border=borders=interior=font=cell=ws=None
    return result


def apply_formats(native,formats):
    for sheet in native['sheets']:
        sheet['shapes']=formats[('shapes',sheet['name'])]
        sheet['rows']=formats[('rows',sheet['name'])]
        sheet['columns']=formats[('columns',sheet['name'])]
        for a,prior in list(sheet['cells'].items()):
            sheet['cells'][a]=(prior[0],formats[(sheet['name'],a)],*prior[2:])

def _text_value(v):
    return '' if v is None else str(v).strip()


def _apply_file(source,target,edits,stamp,diag):
    """Open the original read-only in Excel, write the calculated ranges into the target cells, SaveAs the new
    file, reopen it and verify the written cells. (V3.1: no full-workbook preservation manifest — Excel's own
    SaveAs keeps formatting/images/DRM; only the edited cells are verified, which is what changed.)"""
    if not same_stamp(fingerprint(source),stamp):
        raise RuntimeError('REVIEW: 원본 파일이 비교 이후 바뀜 (크기/수정시각) — 다시 비교하세요')
    with excel_book(source,diag) as pair:
        book,mark=pair
        ws=cell=None
        try:
            mark('writer.recheck')
            for r in edits:
                ws=book.Worksheets.Item(r.sheet)
                cell=ws.Range(r.cell)
                if bool(cell.HasFormula):
                    raise RuntimeError(f'REVIEW: {r.sheet}!{r.cell} 수식 칸')
                if bool(cell.MergeCells) and str(cell.MergeArea.Cells.Item(1,1).Address).replace('$','')!=r.cell:
                    raise RuntimeError(f'REVIEW: {r.sheet}!{r.cell} 병합 영역 안쪽 칸')
                if _text_value(cell.Value2)!=_text_value(r.existing):
                    raise RuntimeError(f'REVIEW: {r.sheet}!{r.cell} 값이 비교 때와 다름')
                cell=ws=None
            mark('writer.edit')
            for r in edits:
                ws=book.Worksheets.Item(r.sheet)
                cell=ws.Range(r.cell)
                if str(r.expected)[:1] in '=+-@':
                    cell.NumberFormat='@'
                cell.Value2=r.expected
                cell=ws=None
            if target.exists() or canonical(target)==canonical(source):
                raise FileExistsError('출력 파일이 이미 있거나 원본과 같음 — 덮어쓰지 않음')
            mark('com.SaveAs')
            book.SaveAs(Filename=str(target),FileFormat=51,CreateBackup=False,AddToMru=False,Local=True)
            mark('writer.saved')
        finally:
            cell=ws=None
            pair=None
            book=None
    if not target.is_file() or target.stat().st_size==0:
        raise RuntimeError('SaveAs 결과 파일이 없음')
    diag.emit('verification','saved.reopen')
    with excel_book(target,diag) as pair:
        saved,mark=pair
        ws=cell=None
        try:
            mark('verification.saved.cells')
            for r in edits:
                ws=saved.Worksheets.Item(r.sheet)
                cell=ws.Range(r.cell)
                if bool(cell.HasFormula) or _text_value(cell.Value2)!=_text_value(r.expected):
                    raise RuntimeError(f'저장본 확인 실패: {r.sheet}!{r.cell}')
                cell=ws=None
        finally:
            cell=ws=saved=pair=None
    diag.emit('verification','saved.verify','OK')
    return 'SAVED'


def _output_root(output_parent):
    from datetime import datetime
    parent=Path(output_parent).resolve()
    parent.mkdir(parents=True,exist_ok=True)
    output=parent/('RangeValidator_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    n=1
    while output.exists():
        n+=1
        output=parent/('RangeValidator_'+datetime.now().strftime('%Y%m%d_%H%M%S')+f'_{n}')
    output.mkdir()
    return output


def _write_groups(session,chosen,output,progress=None):
    try:
        common_root=Path(os.path.commonpath([str(Path(p).parent) for p in session.details]))
    except ValueError:
        common_root=None
    groups={}
    for r in chosen:
        groups.setdefault(r.file,[]).append(r)
    outcomes={}
    for i,(source,edits) in enumerate(groups.items()):
        if progress:
            progress(i,len(groups),Path(source).name)
        if common_root is not None:
            try:
                target=output/Path(source).relative_to(common_root)
            except ValueError:
                target=output/Path(source).name
        else:
            target=output/Path(source).name
        if target.name.casefold()=='rangevalidator_report.xlsx':
            target=target.with_name('Corrected_'+target.name)
        target.parent.mkdir(parents=True,exist_ok=True)
        try:
            state=_apply_file(source,target,edits,session.stamps[source],session.diagnostics)
            reason=f'{len(edits)}개 칸에 계산 범위 기입 후 새 파일로 저장, 저장본 재확인 완료'
            for r in edits:
                outcomes[r.id]=dict(file=source,output=str(target),status=state,reason=reason,drm='원본 DRM 정책에 따름')
        except Exception as exc:
            stage=getattr(exc,'stage','writer.verify')
            for r in edits:
                outcomes[r.id]=dict(file=source,output=str(target) if target.exists() else '',status='REVIEW',stage=stage,code=getattr(exc,'code',None),reason='수정/저장 실패: '+str(exc),drm='')
            session.diagnostics.emit('writer',stage,'FAILED',getattr(exc,'code',None))
    if progress:
        progress(len(groups),len(groups),'완료')
    return outcomes


def save_selected(session,selected_ids,output_parent,progress=None):
    """Write the selected MISMATCH rows (calculated range) into new copies of their documents."""
    session.assert_unchanged()
    ids=list(selected_ids)
    if not ids or len(ids)!=len(set(ids)):
        raise ValueError('수정할 MISMATCH 행을 선택하세요')
    byid={r.id:r for r in session.results}
    if any(i not in byid or byid[i].status!='MISMATCH' or not byid[i].candidate for i in ids):
        raise ValueError('REVIEW/MATCH/SKIP 행은 수정 대상이 아님')
    chosen=[byid[i] for i in ids]
    targets=[(canonical(r.file),r.sheet,r.cell) for r in chosen]
    if len(targets)!=len(set(targets)):
        raise ValueError('같은 칸을 두 번 수정할 수 없음')
    output=_output_root(output_parent)
    with input_locks([p for p in [session.common_path,*session.headers,*session.details] if p]):
        outcomes=_write_groups(session,chosen,output,progress)
    create_report(session,outcomes,output/'RangeValidator_Report.xlsx')
    return output,outcomes


def export_all(session,output_parent,progress=None):
    """Export: every document that has calculated-range differences (MISMATCH candidates) is saved to
    output_parent/RangeValidator_<time>/ with all its ranges updated. Documents without differences are not copied."""
    session.assert_unchanged()
    blocked={f.file for f in getattr(session,'files',[]) if f.read_status!='SUCCESS' or f.status=='ERROR'}
    chosen=[r for r in session.results if r.status=='MISMATCH' and r.candidate and r.file not in blocked]
    if not chosen:
        raise ValueError('계산 범위와 다른 칸(MISMATCH)이 없어 내보낼 파일이 없음')
    output=_output_root(output_parent)
    with input_locks([p for p in [session.common_path,*session.headers,*session.details] if p]):
        outcomes=_write_groups(session,chosen,output,progress)
    create_report(session,outcomes,output/'RangeValidator_Report.xlsx')
    return output,outcomes

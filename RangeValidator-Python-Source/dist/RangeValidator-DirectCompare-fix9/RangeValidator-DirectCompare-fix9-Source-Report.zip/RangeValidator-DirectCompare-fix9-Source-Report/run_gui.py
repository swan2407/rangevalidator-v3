"""RangeValidator DirectCompare fix9 GUI entry point for the report source package."""
import rangevalidator_patch  # Apply the production analysis extensions before opening the GUI.


def main():
    from gui_release import main as gui_main
    gui_main()


if __name__ == '__main__':
    main()

# RangeValidator V3.1 · DirectCompare fix9 제출용 소스

## 목적

C/H의 구조체 비트필드 선언을 기준으로 Excel 상세설계서의 범위를 비교하고, 선택한 항목의 수정본과 결과 보고서를 저장합니다.

## 구성

- `run_gui.py`: 실제 GUI 실행 진입점
- `gui_release.py`: 파일 등록 / 비교 결과 / 수정 및 저장 화면
- `rangevalidator_patch.py`: fix9 분석 확장
- `rangevalidator/`: 분석·읽기·비교·저장·보고서·실행 진단 코드
- `requirements-lock.txt`: 실행 의존성 목록
- `requirements-build-lock.txt`: 빌드 의존성 목록
- `pyproject.toml`: Python 패키지 설정
- `packaging/RangeValidator.spec`: Windows 단일 EXE 빌드 설정
- `licenses/`: 제3자 의존성 라이선스
- `KNOWN_LIMITATIONS.md`: 현재 fix9의 확인된 한계
- `SHA256SUMS.txt`: 제출 파일 해시

테스트 폴더, 자가검사·smoke·probe 모듈, 개발·검증 도구, 과거 작업/검증 문서, 빌드 중간물, EXE, 기존 ZIP, 예제 입력·출력, 로그 및 캐시는 제외했습니다. 실행 중 오류를 기록하는 진단 기능은 유지했습니다.

## 실행

Windows CPython 3.13 x64와 Tcl/Tk를 사용합니다.

```powershell
py -3.13 -m pip install -r requirements-lock.txt
py -3.13 run_gui.py
```

Excel COM 읽기 및 수정본 저장에는 Microsoft Excel이 필요합니다. 주요 사용 경로는 `run_gui.py`입니다.

## 재빌드

```powershell
py -3.13 -m pip install -r requirements-lock.txt -r requirements-build-lock.txt
py -3.13 -m PyInstaller --distpath dist --workpath build packaging/RangeValidator.spec
```

결과: `dist/RangeValidator-DirectCompare-fix9-Windows-x64.exe`

## 제출본의 범위

fix9의 업무 기능 코드는 유지하고 개발·검사 항목을 제외한 소스 정리본입니다. 검사 전용 실행 옵션과 사용하지 않는 초기 GUI 진입점도 제외했습니다. EXE는 새로 빌드하지 않았습니다. 현재 fix9의 알려진 문제는 이 정리 작업으로 수정되지 않았습니다.

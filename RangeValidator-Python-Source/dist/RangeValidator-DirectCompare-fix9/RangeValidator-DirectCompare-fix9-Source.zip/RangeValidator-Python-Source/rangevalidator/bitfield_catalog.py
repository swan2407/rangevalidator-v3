"""Conservative C/H bit-field inventory for use independently of Excel."""
import ast
from collections import Counter, defaultdict
from dataclasses import dataclass, field, replace
from functools import cached_property
from pathlib import Path
import operator
import re

from .analysis import (BASE_PROFILES, QUALIFIERS, BitField, Diagnostic, SourceModel, Token,
                       _CMT_STR, _Parser, canonical_keyword, identifier, matching_names, tokenize)


@dataclass(frozen=True, order=True)
class Origin:
    file: str
    line: int
    ordinal: int = 0


@dataclass(frozen=True)
class TypeLink:
    status: str
    definition: Origin | None = None
    integer_type: str = ''
    evidence: tuple[Origin, ...] = ()
    pointer_depth: int = 0
    qualifiers: tuple[tuple[str, ...], ...] = ()
    assumptions: tuple[str, ...] = ()


@dataclass(frozen=True)
class VariableDeclaration:
    name: str
    spelling: str
    origin: Origin
    arrays: tuple[str, ...]
    qualifiers: tuple[tuple[str, ...], ...]
    storage: str
    kind: str
    conditional: bool
    target: Origin | None = None

    @property
    def pointer_depth(self):
        return len(self.qualifiers) - 1


@dataclass(frozen=True)
class VariableBinding:
    status: str
    declarations: tuple[VariableDeclaration, ...] = ()
    type_link: TypeLink | None = None
    nested_only: bool = False


@dataclass(frozen=True)
class FunctionScope:
    file: str
    status: str
    variables: dict[str, VariableBinding] = field(default_factory=dict)
    alternatives: tuple['FunctionScope', ...] = ()
    parameter_issues: dict[str, str] = field(default_factory=dict)
    linkage_reason: str = ''
    uncollected_parameters: bool = False


@dataclass(frozen=True)
class _Function:
    name: str
    origin: Origin
    internal: bool
    conditional: bool
    parameters: tuple[VariableDeclaration | None, ...]
    locals: tuple[tuple[VariableDeclaration, bool], ...]
    definition: bool
    return_type: tuple[str, ...]
    prototyped: bool
    raw_parameters: tuple = ()


@dataclass(frozen=True)
class CatalogField:
    declaration: BitField
    width_expression: str
    status: str
    type_link: TypeLink


@dataclass(frozen=True)
class CatalogStruct:
    origin: Origin
    name: str
    tag: str
    aliases: tuple[str, ...]
    status: str
    fields: tuple[CatalogField, ...]
    ordinary_members: tuple[str, ...] = ()


@dataclass
class BitfieldCatalog:
    definitions: dict[Origin, CatalogStruct]
    links: dict[tuple[str, str], TypeLink]
    diagnostics: tuple[Diagnostic, ...]
    source_scopes: dict[str, dict[str, bool]] = field(default_factory=dict)
    conditional_declarations: frozenset[Origin] = frozenset()
    variables: dict[str, tuple[VariableDeclaration, ...]] = field(default_factory=dict)
    variable_bindings: dict[tuple[str | None, str], VariableBinding] = field(default_factory=dict)
    functions: dict[str, tuple[FunctionScope, ...]] = field(default_factory=dict)

    def lookup_function(self, file, name):
        names = matching_names(self.functions, name)
        candidates = tuple(scope for spelling in names for scope in self.functions[spelling])
        if file is not None:
            file = str(Path(file).resolve())
            visible = self.source_scopes.get(file, {})
            candidates = (tuple(scope for scope in candidates if scope.file == file)
                          or tuple(scope for scope in candidates if scope.file in visible))
        if len(candidates) == 1:
            scope = candidates[0]
            if scope.status == 'RESOLVED' and file and self.source_scopes.get(file, {}).get(scope.file, False):
                return replace(scope, status='CONDITIONAL')
            return scope
        if len(names) == 1 and candidates and len({scope.file for scope in candidates}) == 1:
            return FunctionScope(candidates[0].file, 'MULTIPLE', alternatives=candidates)
        if candidates or names:
            return FunctionScope(file or '', 'AMBIGUOUS')
        return FunctionScope(file or '', 'MISSING')

    @cached_property
    def variable_spellings(self):
        spellings = defaultdict(list)
        for scope, name in self.variable_bindings:
            spellings[scope, name.casefold()].append(name)
        return spellings

    def lookup_variable(self, file, name, local=None):
        scope = str(Path(file).resolve()) if file is not None else None
        local = local or {}
        if name in local:
            return local[name]
        local_names = matching_names(local, name)
        if len(local_names) == 1:
            return local[local_names[0]]
        if local_names:
            return VariableBinding('AMBIGUOUS')
        if (scope, name) in self.variable_bindings:
            return self.variable_bindings[scope, name]
        names = set(self.variable_spellings.get((scope, name.casefold()), ()))
        names.update(matching_names(local, name))
        if len(names) != 1:
            return VariableBinding('AMBIGUOUS' if names else 'MISSING')
        spelling = names.pop()
        return local.get(spelling) or self.variable_bindings[scope, spelling]

    @cached_property
    def function_declaration_locations(self):
        locations = defaultdict(set)
        for function, scopes in self.functions.items():
            for scope in scopes:
                for name, binding in scope.variables.items():
                    locations[name].update((d.origin, function) for d in binding.declarations
                                           if d.origin.file == scope.file)
        return {name: tuple(sorted(origins)) for name, origins in locations.items()}

    def lookup(self, file, spelling):
        """Resolve a type in an input file's scope, preserving uncertainty."""
        file = str(Path(file).resolve())
        spelling = ' '.join(canonical_keyword(word) for word in spelling.split())
        names = matching_names({name for path, name in self.links if path == file}, spelling)
        if len(names) == 1:
            return self.links[file, names[0]]
        return TypeLink('AMBIGUOUS' if names else 'UNRESOLVED')

    @cached_property
    def type_candidates(self):
        types = defaultdict(dict)
        for definition in self.definitions.values():
            for name in {definition.name, definition.tag, *definition.aliases} - {''}:
                types[name][definition.origin] = definition
        for (_, name), link in self.links.items():
            if link.definition in self.definitions and not link.pointer_depth and not name.startswith('struct '):
                types[name][link.definition] = self.definitions[link.definition]
        return {name: tuple(definitions.values()) for name, definitions in types.items()}


@dataclass(frozen=True)
class _Declaration:
    target: str | Origin
    origin: Origin
    conditional: bool = False
    qualifiers: tuple[tuple[str, ...], ...] = ()


@dataclass
class _Unit:
    types: dict = field(default_factory=lambda: defaultdict(list))
    macros: dict = field(default_factory=lambda: defaultdict(list))
    includes: dict = field(default_factory=dict)
    definitions: dict = field(default_factory=dict)
    reviews: list = field(default_factory=list)
    conditional_declarations: set[Origin] = field(default_factory=set)
    variables: list[VariableDeclaration] = field(default_factory=list)
    functions: list[_Function] = field(default_factory=list)
    parameter_typedefs: dict = field(default_factory=lambda: defaultdict(list))


class _Collector(_Parser):
    collect_bitfields = True

    def parse_bitfield(self, st, member, declared, width_expr, at):
        # The temporary field stores the raw width until the linkage pass.
        return BitField(st.name, st.tag, member, declared, 0, self.file, at, note=width_expr)


_DIRECTIVE = re.compile(r'^\s*#\s*(\w+)\b\s*(.*)$')
_INCLUDE = re.compile(r'"([^"]+)"$')
_NEGATED_DEFINED = re.compile(r'!\s*defined(?:\s*\(\s*(\w+)\s*\)|\s+(\w+))', re.IGNORECASE)
_INTEGER = re.compile(r'\b(0[xX][0-9a-fA-F]+|0[bB][01]+|0[0-7]*|[1-9][0-9]*)([uUlL]*)\b')
_OPERATORS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.LShift: operator.lshift,
    ast.RShift: operator.rshift, ast.BitAnd: operator.and_, ast.BitOr: operator.or_,
    ast.BitXor: operator.xor,
}


def _guard(directives, lines):
    """Recognize a conventional whole-file include guard."""
    prologue = [line for line, command, body in directives[:1] if command == 'pragma'
                and body.strip().casefold() == 'once']
    directives = directives[len(prologue):]
    if len(directives) < 3:
        return None
    (start, opening, name), (_, define, body), (end, closing, _) = (
        directives[0], directives[1], directives[-1])
    name = name.strip()
    if opening == 'if':
        match = _NEGATED_DEFINED.fullmatch(name)
        name = next(part for part in match.groups() if part) if match else ''
    elif opening != 'ifndef':
        return None
    if (not identifier(name) or define != 'define'
            or not re.fullmatch(rf'{re.escape(name)}(?:\s+[01])?\s*', body) or closing != 'endif'
            or any(text.strip() for index, text in enumerate(lines[:start - 1], 1) if index not in prologue)
            or any(text.strip() for text in lines[end:])):
        return None
    depth = 0
    for _, command, _ in directives[:-1]:
        if command in ('if', 'ifdef', 'ifndef'):
            depth += 1
        elif command == 'endif':
            depth -= 1
        if depth == 0 or (depth == 1 and command in ('elif', 'else')):
            return None
    return start if depth == 1 else None


def _expand_declaration_macros(tokens, file, events, inputs):
    """Expand empty and type-keyword aliases from registered includes in source order."""
    expanded, active = [], {}
    visited = {file}

    def apply(name, value, depth):
        if name is not None:
            if value is None:
                active.pop(name, None)
            else:
                active[name] = value
            return
        if value not in inputs or value in visited or depth >= 64:
            active.clear()
            return
        visited.add(value)
        for _, included_name, included_value in inputs[value]:
            apply(included_name, included_value, depth + 1)

    events = iter(events)
    event = next(events, None)
    for token in tokens:
        while event is not None and event[0] < token.line:
            _, name, value = event
            apply(name, value, 0)
            event = next(events, None)
        replacement = active.get(token.text)
        if replacement is None:
            expanded.append(token)
        else:
            expanded.extend(Token(word, token.line) for word in replacement)
    return expanded


def _prepare_unit(source, file, files):
    unit = _Unit()
    lines = source.lstrip('\ufeff').splitlines()
    # Join splices before stripping comments, retaining physical line numbers.
    for i in range(len(lines) - 2, -1, -1):
        if lines[i].endswith('\\'):
            lines[i] = lines[i][:-1] + lines[i + 1]
            lines[i + 1] = ''
    source = _CMT_STR.sub(lambda m: m[0] if m[0][0] in "\"'" else ' ' + '\n' * m[0].count('\n'),
                          '\n'.join(lines))
    lines = source.split('\n')
    directives = [(i, match[1].casefold(), match[2]) for i, line in enumerate(lines, 1)
                  if (match := _DIRECTIVE.fullmatch(line))]
    guard = _guard(directives, lines)
    conditions, conditional, macro_events = [], set(), []
    by_line = {line: (command, body.strip()) for line, command, body in directives}
    for i, line in enumerate(lines, 1):
        if i not in by_line:
            if any(conditions):
                conditional.add(i)
            continue
        command, body = by_line[i]
        lines[i - 1] = ''
        if command in ('if', 'ifdef', 'ifndef'):
            conditions.append(i != guard)
        elif command == 'endif' and conditions:
            conditions.pop()
        elif command in ('define', 'undef'):
            match = re.match(r'([A-Za-z_]\w*)(.*)', body)
            if match:
                name, expr = match.groups()
                replacement = None
                words = [canonical_keyword(word) for word in expr.split()]
                if command == 'define' and not any(conditions) and not expr.startswith('('):
                    if not words or ' '.join(words) in BASE_PROFILES or words == ['struct']:
                        replacement = tuple(words)
                macro_events.append((i, name, replacement))
                target = expr.strip() if command == 'define' and not expr.startswith('(') else ''
                unit.macros[name].append(_Declaration(target, Origin(file, i), any(conditions)))
        if command == 'include':
            local = None
            match = _INCLUDE.fullmatch(body)
            if match:
                local = str((Path(file).parent / match[1]).resolve())
                local = next((path for path in files if path.casefold() == local.casefold()), local)
                if local in files:
                    unit.includes[local] = unit.includes.get(local, True) and any(conditions)
            macro_events.append((i, None, None if any(conditions) else local))
        elif command in ('include_next', 'import') or (command == 'pragma' and body.casefold() != 'once'):
            macro_events.append((i, None, None))
    return unit, '\n'.join(lines), conditional, macro_events


def _collect_units(sources, files):
    prepared = {file: _prepare_unit(source, file, files) for file, source in sources.items()}
    inputs = {file: item[3] for file, item in prepared.items()}
    return {file: _collect_prepared(item, file, inputs) for file, item in prepared.items()}


def _collect_prepared(prepared, file, inputs):
    unit, source, conditional, macro_events = prepared
    tokens = tokenize(source, file, unit.reviews)
    if macro_events:
        tokens = _expand_declaration_macros(tokens, file, macro_events, inputs)
    parser = _Collector(tokens, file, SourceModel())
    def function(head, body):
        declaration = _collect_function(parser, head, body, conditional)
        if declaration is not None:
            unit.functions.append(declaration)

    for tokens in parser.declarations(function):
        words = [token.text for token in tokens]
        origin = Origin(file, tokens[0].line)
        uncertain = any(token.line in conditional for token in tokens)
        if uncertain:
            unit.conditional_declarations.add(origin)
        typedef = words[0] == 'typedef'
        offset = next((i for i in range(int(typedef), len(words))
                       if words[i] not in QUALIFIERS), len(words))
        try:
            kind = words[offset]
            after_kind = offset + 1
            if after_kind < len(words) and identifier(words[after_kind]):
                after_kind += 1
            if kind == 'struct' and words[after_kind:after_kind + 1] == ['{']:
                nested_start = len(parser.m.types)
                st, end, tag = parser.parse_aggregate(tokens, offset, typedef, origin.line)
                if st is None:
                    continue
                # Column-independent identity also distinguishes definitions on the same line.
                definition = _definition_id(Origin(file, st.line), unit.definitions)
                names = []
                if typedef:
                    names = _typedefs(parser, tokens[end:], definition, origin, uncertain, unit)
                if names:
                    parser.rename(st, names[0])
                unit.definitions[definition] = (st, uncertain)
                for nested in parser.m.types[nested_start:]:
                    nested_origin = _definition_id(Origin(file, nested.line), unit.definitions)
                    unit.definitions[nested_origin] = (nested, uncertain)
                if tag:
                    unit.types['struct ' + tag].append(_Declaration(definition, origin, uncertain))
                if not typedef:
                    _collect_variables(parser, words[:offset], tokens[end:], origin, uncertain, unit,
                                       'struct ' + tag if tag else st.name, definition)
            elif kind == 'struct' and len(words) == 2 and identifier(words[1]):
                spelling = 'struct ' + words[1]
                unit.types[spelling].append(_Declaration(spelling, origin, uncertain))
            elif typedef and '{' in words:
                unit.reviews.append(Diagnostic(file, origin.line, 'Unsupported aggregate typedef'))
            elif typedef:
                _collect_typedef(parser, tokens[1:], origin, uncertain, unit)
            else:
                prototype = _collect_function(parser, tokens, None, conditional)
                if prototype is not None:
                    unit.functions.append(prototype)
                else:
                    _collect_variables(parser, None, tokens, origin, uncertain, unit)
        except (IndexError, ValueError, RecursionError) as exc:
            unit.reviews.append(Diagnostic(file, origin.line, f'Declaration skipped: {exc}'))
    return unit


def _definition_id(origin, definitions):
    ordinal = 0
    while Origin(origin.file, origin.line, ordinal) in definitions:
        ordinal += 1
    return Origin(origin.file, origin.line, ordinal)


_CV = {'const', 'volatile', 'restrict', '__restrict', '__restrict__'}
_STORAGE = {'extern', 'static', '_Thread_local', 'register', 'auto'}
_NON_STRUCT_SCALARS = {'void', 'float', 'double', 'long double'}


def _declarator(words):
    """Split a simple object declarator into name, pointer qualifiers and dimensions."""
    cursor, qualifiers = 0, []
    while cursor < len(words) and words[cursor] == '*':
        cursor += 1
        start = cursor
        while cursor < len(words) and words[cursor] in _CV:
            cursor += 1
        qualifiers.append(tuple(sorted(set(words[start:cursor]))))
    if cursor == len(words) or not identifier(words[cursor]):
        return None
    name = words[cursor]
    cursor += 1
    dimensions = []
    while cursor < len(words) and words[cursor] == '[':
        try:
            end = words.index(']', cursor + 1)
        except ValueError:
            return None
        extent = words[cursor + 1:end]
        if '[' in extent:
            return None
        dimensions.append(' '.join(extent))
        cursor = end + 1
    if cursor != len(words) and words[cursor] != '=':
        return None
    return name, tuple(qualifiers), tuple(dimensions), cursor < len(words)


def _specifier_end(words):
    for i, word in enumerate(words):
        if word in ('*', '('):
            return i - int(word == '(' and i > 0 and identifier(words[i - 1]))
        if word in ('[', '='):
            return i - 1
    return len(words) - 1


def _collect_variables(parser, spec, tokens, origin, uncertain, unit, spelling='', target=None):
    unit.variables.extend(_variable_declarations(parser, spec, tokens, origin, uncertain, spelling, target))


def _variable_declarations(parser, spec, tokens, origin, uncertain, spelling='', target=None):
    parts = parser.split(tokens)
    if not parts:
        return
    if spec is None:
        first = [token.text for token in parts[0]]
        end = _specifier_end(first)
        if end < 1:
            return
        spec, parts[0] = first[:end], parts[0][end:]
        spelling = ' '.join(word for word in spec if word not in _CV | _STORAGE)
    storage = 'static' if 'static' in spec else 'extern' if 'extern' in spec else ''
    if not spelling or ('(' in spec or '{' in spec) or any(word in spec for word in ('register', 'auto')):
        return
    base_cv = tuple(sorted(set(spec) & _CV))
    for part in parts:
        parsed = _declarator([token.text for token in part])
        if parsed is None:
            continue
        name, pointers, arrays, initialized = parsed
        kind = 'DEFINITION' if initialized else 'DECLARATION' if storage == 'extern' else 'TENTATIVE'
        yield VariableDeclaration(name, spelling, origin, arrays,
                                  (base_cv, *pointers), storage, kind, uncertain, target)


def _unsupported_pointer(tokens, origin, uncertain):
    words = [t.text for t in tokens]
    if '(' not in words or '=' in words[:words.index('(')]:
        return None
    opening = words.index('(')
    base = ' '.join(word for word in words[:opening] if word not in _CV | _STORAGE | {'*'})
    if not _type_spelling(base):
        return None
    match = re.match(r"\( (?:\* |const |volatile |restrict )+([A-Za-z_]\w*) (?:\)|\[)",
                     ' '.join(words[opening:]))
    if not match:
        return None
    return VariableDeclaration(match[1], '<complex declarator>', origin, (), ((),), '',
                               'UNSUPPORTED', uncertain)


def _local_declarations(parser, body, conditional):
    """Scan statement boundaries and retain whether a declaration is in a nested scope."""
    pending, nesting = [], 0
    declarations, shadowed_types = [], set()
    parentheses = brackets = initializer = 0
    for token in body:
        word = token.text
        if word == '{' and not parentheses and not brackets:
            head = [t.text for t in pending]
            aggregate = bool(head and head[0] in ('struct', 'union', 'enum', 'typedef'))
            if initializer or '=' in head or aggregate:
                initializer += 1
            else:
                pending.clear()
                nesting += 1
                continue
        elif word == '}' and not parentheses and not brackets:
            if initializer:
                initializer -= 1
            else:
                pending.clear()
                nesting -= 1
                continue
        elif word == '(':
            parentheses += 1
        elif word == ')':
            parentheses -= 1
        elif word == '[':
            brackets += 1
        elif word == ']':
            brackets -= 1
        if word == ';' and parentheses == 1 and pending and pending[0].text == 'for':
            # The initializer's declaration is scoped to the loop, not the whole function.
            if len(pending) > 2 and not any(t.text == ';' for t in pending):
                part = pending[2:]
                origin = Origin(parser.file, part[0].line)
                declarations.extend((d, True) for d in _variable_declarations(
                    parser, None, part, origin, any(t.line in conditional for t in part))
                    if _type_spelling(d.spelling))
        if word != ';' or parentheses or brackets or initializer:
            pending.append(token)
            continue
        if not pending:
            continue
        origin = Origin(parser.file, pending[0].line)
        uncertain = any(t.line in conditional for t in pending)
        words = [t.text for t in pending]
        if words[0] == 'typedef':
            scratch = _Unit()
            if '{' in words and '}' in words:
                tail = len(words) - words[::-1].index('}')
                _typedefs(parser, pending[tail:], '', origin, uncertain, scratch)
            else:
                _collect_typedef(parser, pending[1:], origin, uncertain, scratch)
            shadowed_types.update(scratch.types)
        elif words[0] in ('struct', 'union', 'enum') and (
                len(words) == 2 or (len(words) > 2 and words[2] == '{') or words[1:2] == ['{']):
            if len(words) > 1 and identifier(words[1]):
                shadowed_types.add(' '.join(words[:2]))
            if '}' in words:
                tail = len(words) - words[::-1].index('}')
                declarations.extend((d, nesting > 0) for d in _variable_declarations(
                    parser, [], pending[tail:], origin, uncertain, '<local aggregate>'))
        else:
            parsed = [d for d in _variable_declarations(parser, None, pending, origin, uncertain)
                      if _type_spelling(d.spelling)]
            if not parsed:
                unsupported = _unsupported_pointer(pending, origin, uncertain)
                if unsupported:
                    parsed.append(unsupported)
            declarations.extend((d, nesting > 0) for d in parsed)
        pending.clear()
    return tuple((replace(d, spelling='<local type>') if d.spelling in shadowed_types else d, nested)
                 for d, nested in declarations)


def _type_spelling(spelling):
    words = spelling.split()
    return (spelling in BASE_PROFILES or spelling == 'char' or spelling in _NON_STRUCT_SCALARS
            or (len(words) == 1 and identifier(words[0]))
            or (len(words) == 2 and words[0] in ('struct', 'union', 'enum') and identifier(words[1])))


def _collect_function(parser, head, body, conditional):
    words = [t.text for t in head]
    if not words or words[0] == 'typedef' or '(' not in words:
        return None
    opening = words.index('(')
    if (opening < 2 or not identifier(words[opening - 1]) or words[-1] != ')'
            or '=' in words[:opening] or '{' in words[:opening]):
        return None
    return_type = tuple(word for word in words[:opening - 1] if word not in _STORAGE | {'inline'})
    if not _type_spelling(' '.join(word for word in return_type if word != '*' and word not in _CV)) and return_type != ('void',):
        return None
    parameters = []
    raw_parameters = []
    if words[opening + 1:-1] != ['void']:
        for part in parser.split(head[opening + 1:-1]):
            raw_parameters.append(tuple(t.text for t in part))
            origin = Origin(parser.file, part[0].line)
            uncertain = any(t.line in conditional for t in part)
            declarations = tuple(_variable_declarations(parser, None, part, origin, uncertain))
            parameter = next((d for d in declarations if _type_spelling(d.spelling)), None)
            if parameter is None and body is None:
                # Unnamed parameters in prototypes still carry type information.
                unnamed = next(iter(_variable_declarations(
                    parser, None, [*part, Token('_rv_parameter', part[-1].line)], origin, uncertain)), None)
                if unnamed and _type_spelling(unnamed.spelling):
                    parameter = unnamed
            parameter = parameter or _unsupported_pointer(part, origin, uncertain)
            parameters.append(replace(parameter, kind='PARAMETER') if parameter else None)
    return _Function(words[opening - 1], Origin(parser.file, head[0].line),
                     'static' in words[:opening], any(t.line in conditional for t in head),
                     tuple(parameters), tuple(_local_declarations(parser, body or (), conditional)),
                     body is not None, return_type, opening + 1 < len(words) - 1, tuple(raw_parameters))


def _typedefs(parser, tail, target, origin, uncertain, unit, base_cv=()):
    names = []
    for part in parser.split(tail):
        words = [token.text for token in part]
        from .function_parameters import _declarator as parameter_declarator
        try:
            alias, _ = parameter_declarator(words)
            if alias:
                unit.parameter_typedefs[alias].append((target, base_cv, tuple(words), origin, uncertain))
        except ValueError:
            pass
        parsed = _declarator(words)
        if parsed is not None:
            name, pointers, arrays, initialized = parsed
            if not arrays and not initialized:
                if not pointers:
                    names.append(name)
                unit.types[name].append(_Declaration(target, origin, uncertain, (base_cv, *pointers)))
                continue
        name = next((word for word in words if identifier(word)), '')
        if name:
            unit.types[name].append(_Declaration('', origin, uncertain))
        unit.reviews.append(Diagnostic(origin.file, origin.line, 'Unsupported typedef declarator'))
    return names


def _collect_typedef(parser, tokens, origin, uncertain, unit):
    if not tokens:
        return
    first = [token.text for token in parser.split(tokens)[0]]
    end = _specifier_end(first)
    # In an array-pointer typedef the parenthesis starts the declarator itself.
    if '(' in first and first[first.index('(') + 1:first.index('(') + 2] == ['*']:
        end = first.index('(')
    if end < 1:
        return
    spec = first[:end]
    target = ' '.join(word for word in spec if word not in QUALIFIERS)
    _typedefs(parser, tokens[end:], target, origin, uncertain, unit, tuple(sorted(set(spec) & _CV)))
    if target.startswith('struct ') and len(target.split()) == 2:
        unit.types[target].append(_Declaration(target, origin, uncertain))


def _qualify(link, qualifiers):
    if not qualifiers or (link.status not in ('STRUCT', 'INTEGER', 'SCALAR')
                          and not (link.status == 'CONDITIONAL' and (link.definition is not None or link.integer_type))):
        return link
    base = link.qualifiers or ((),)
    combined = (*base[:-1], tuple(sorted(set(base[-1]) | set(qualifiers[0]))), *qualifiers[1:])
    return replace(link, pointer_depth=len(combined) - 1, qualifiers=combined)


def _type_identity(link):
    status = link.status
    if status == 'CONDITIONAL':
        if link.definition is not None:
            status = 'STRUCT'
        elif link.integer_type:
            status = 'SCALAR' if link.integer_type in _NON_STRUCT_SCALARS else 'INTEGER'
    return status, link.definition, link.integer_type, link.qualifiers


def _visible(file, units):
    visible, pending = {}, [(file, False)]
    while pending:
        item, conditional = pending.pop()
        if item not in visible or (visible[item] and not conditional):
            visible[item] = conditional
            pending.extend((path, conditional or guarded)
                           for path, guarded in units[item].includes.items())
    return visible


class _Registry:
    def __init__(self, units):
        self.units = units
        self.scopes = {file: _visible(file, units) for file in units}
        self.definitions = {key: value for unit in units.values() for key, value in unit.definitions.items()}
        self.type_names = {file: {name for path in scope for name in units[path].types}
                           for file, scope in self.scopes.items()}
        self.macro_names = {file: {name for path in scope for name in units[path].macros}
                            for file, scope in self.scopes.items()}
        self.global_scope = dict.fromkeys(units, False)
        self.all_type_names = set().union(*self.type_names.values())
        self.all_macro_names = set().union(*self.macro_names.values())

    def resolve(self, file, name, root=None, seen=frozenset()):
        root = root or file
        name = ' '.join(canonical_keyword(word) for word in name.split())
        if (name in BASE_PROFILES and name != 'bool') or name == 'char':
            return TypeLink('INTEGER', integer_type=name)
        if name in _NON_STRUCT_SCALARS:
            return TypeLink('SCALAR', integer_type=name)
        scope = self.scopes[file]
        is_tag = name.startswith('struct ')
        if is_tag:
            scope = self.scopes[root]
        names = matching_names(self.type_names[root if is_tag else file], name)
        if not names and not getattr(self, 'isolated', False):
            scope = self.global_scope
            names = matching_names(self.all_type_names, name)
        if len(names) > 1:
            return TypeLink('AMBIGUOUS')
        if names:
            name = names[0]
        key = (file, name)
        if key in seen or len(seen) >= 128:
            return TypeLink('UNRESOLVED')
        declarations = [d for path in sorted(scope) for d in self.units[path].types.get(name, ())]
        if not getattr(self, 'isolated', False) and is_tag and not any(
                isinstance(d.target, Origin) for d in declarations) and declarations:
            # Comparison inputs form one catalog, even without an include edge.
            declarations.extend(d for path in sorted(self.units)
                                for spelling in matching_names(self.units[path].types, name)
                                for d in self.units[path].types[spelling]
                                if isinstance(d.target, Origin))
        if not declarations and not is_tag:
            macro_scope = self.scopes[file]
            macro_names = matching_names(self.macro_names[file], name)
            if not macro_names and not getattr(self, 'isolated', False):
                macro_scope = self.global_scope
                macro_names = matching_names(self.all_macro_names, name)
            if len(macro_names) > 1:
                return TypeLink('AMBIGUOUS')
            if macro_names:
                declarations = [d for path in sorted(macro_scope)
                                for d in self.units[path].macros.get(macro_names[0], ())]
                scope = macro_scope
        evidence = tuple(sorted({d.origin for d in declarations}))
        conditional = any(d.conditional or scope.get(d.origin.file, False) for d in declarations)
        if is_tag:
            declarations = [d for d in declarations if d.target != name]
            if not declarations and evidence:
                return TypeLink('CONDITIONAL' if conditional else 'INCOMPLETE', evidence=evidence)
        if not declarations:
            # The photographed code uses uint without showing its definition. Explicit
            # source typedefs/macros always win; this fallback is recorded in the result.
            if name.casefold() == 'uint':
                return TypeLink('INTEGER', integer_type='unsigned int',
                                assumptions=('uint 정의 미수집: 관용 타입 unsigned int 적용',))
            return TypeLink('UNRESOLVED', evidence=evidence)
        targets = dict.fromkeys((d.origin.file, d.target, d.qualifiers) for d in declarations)
        links = [_qualify(TypeLink('STRUCT', target) if isinstance(target, Origin)
                          else self.resolve(path, target, root, seen | {key}), qualifiers)
                 for path, target, qualifiers in targets]
        first = links[0]
        outcomes = {_type_identity(link) for link in links}
        conditional |= any(link.status == 'CONDITIONAL' for link in links)
        evidence = tuple(sorted(set(evidence).union(*(link.evidence for link in links))))
        if len(outcomes) > 1 or (first.status in ('UNRESOLVED', 'INCOMPLETE')
                                and len({d.target for d in declarations}) > 1):
            return TypeLink('CONDITIONAL' if conditional else 'AMBIGUOUS', evidence=evidence)
        assumptions = tuple(sorted({note for link in links for note in link.assumptions}))
        return replace(first, status='CONDITIONAL' if conditional else first.status,
                       evidence=evidence, assumptions=assumptions)

    def width(self, expression, file, *, allow_conditional=False):
        return self.constant(expression, file, allow_conditional=allow_conditional, minimum=0, maximum=32767)

    def constant(self, expression, file=None, *, allow_conditional=True,
                 minimum=-(1 << 63), maximum=(1 << 64) - 1):
        """Evaluate a bounded C integer expression using the collected definitions."""
        scope = self.scopes.get(file, self.global_scope)
        available = self.macro_names.get(file, self.all_macro_names)
        unsigned_literals = False

        def expand(text, stack):
            def substitute(match):
                name = match[0]
                names = matching_names(available, name)
                macro_scope = scope
                if not names:
                    names = matching_names(self.all_macro_names, name)
                    macro_scope = self.global_scope
                if len(names) != 1:
                    raise ValueError('missing or conflicting macro spelling')
                name = names[0]
                if name in stack or len(stack) >= 32:
                    raise ValueError('recursive macro')
                declarations = [d for path in macro_scope for d in self.units[path].macros.get(name, ())]
                bodies = {d.target for d in declarations}
                if len(bodies) != 1 or (not allow_conditional and any(
                        d.conditional or macro_scope[d.origin.file] for d in declarations)):
                    raise ValueError('missing, conflicting or conditional macro')
                body = bodies.pop()
                if not body:
                    raise ValueError('unsupported macro')
                return expand(body, stack | {name})

            if len(text) > 512:
                raise ValueError('oversized expression')
            # Textual expansion preserves C operator precedence for unparenthesized macros.
            parts, size, end = [], 0, 0
            for match in re.finditer(r"\b[A-Za-z_]\w*\b", text):
                part = text[end:match.start()] + substitute(match)
                size += len(part)
                if size > 512:
                    raise ValueError('oversized expansion')
                parts.append(part)
                end = match.end()
            return ''.join(parts) + text[end:]

        def evaluate(node):
            if isinstance(node, ast.Constant) and type(node.value) is int:
                value = node.value
            elif isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
                value = evaluate(node.operand)
                if isinstance(node.op, ast.USub):
                    value = -value
            elif isinstance(node, ast.BinOp) and type(node.op) in _OPERATORS:
                left, right = evaluate(node.left), evaluate(node.right)
                if isinstance(node.op, (ast.LShift, ast.RShift)) and right > 63:
                    raise ValueError('oversized shift')
                if isinstance(node.op, (ast.FloorDiv, ast.Mod)) and (left < 0 or right < 0):
                    quotient = abs(left) // abs(right)
                    quotient = -quotient if (left < 0) != (right < 0) else quotient
                    value = quotient if isinstance(node.op, ast.FloorDiv) else left - quotient * right
                else:
                    value = _OPERATORS[type(node.op)](left, right)
            else:
                raise ValueError('unsupported width expression')
            if value < 0 and unsigned_literals:
                raise ValueError('unsigned wraparound needs target integer semantics')
            if not minimum <= value <= maximum:
                raise ValueError('constant outside supported width-expression domain')
            return value

        def literal(match):
            digits = match[1]
            base = 0 if digits.lower().startswith(('0x', '0b')) else 8 if digits.startswith('0') else 10
            return str(int(digits, base))

        if not expression or len(expression) > 512 or '//' in expression:
            return None
        try:
            expanded = expand(expression, frozenset())
            if '//' in expanded:
                return None
            unsigned_literals = any('u' in match[2].lower() for match in _INTEGER.finditer(expanded))
            normalized = _INTEGER.sub(literal, expanded).replace('/', '//')
            if not re.fullmatch(r'[0-9+*/%()<>|&^ \t-]+', normalized):
                return None
            return evaluate(ast.parse(normalized, mode='eval').body)
        except (SyntaxError, ValueError, ZeroDivisionError, RecursionError):
            return None


def _field(raw, registry, blocked):
    width = registry.width(raw.note, raw.file)
    conditional_width = False
    if width is None:
        width = registry.width(raw.note, raw.file, allow_conditional=True)
        conditional_width = width is not None
    link = registry.resolve(raw.file, raw.declared_type)
    signed = None
    minimum = maximum = None
    integer = link.integer_type
    if blocked and blocked != 'CONDITIONAL':
        status = blocked
    elif width is None or not 1 <= width <= 1024 or (integer == '_Bool' and width != 1):
        status = 'WIDTH_UNRESOLVED'
    elif (link.status not in ('INTEGER', 'CONDITIONAL') or integer not in BASE_PROFILES
          or link.pointer_depth or integer in ('char', 'int')):
        if link.status in ('INTEGER', 'STRUCT') or integer:
            status = 'SIGNEDNESS_UNRESOLVED'
        else:
            status = 'TYPE_UNRESOLVED' if link.status == 'CONDITIONAL' else link.status
    else:
        signed = BASE_PROFILES[integer][0]
        minimum = -(1 << (width - 1)) if signed else 0
        maximum = (1 << (width - int(signed))) - 1
        status = ('CONDITIONAL' if blocked == 'CONDITIONAL' or link.status == 'CONDITIONAL'
                  or conditional_width else 'RESOLVED')
    declaration = BitField(raw.struct_name, raw.struct_tag, raw.member, raw.declared_type,
                           width or 0, raw.file, raw.line, signed, minimum, maximum,
                           '' if status == 'RESOLVED' else status)
    return CatalogField(declaration, raw.note, status, link)


def _bind_declarations(registry, declarations, root):
    links = []
    conditional = False
    for declaration in declarations:
        file = declaration.origin.file
        context = root if file in registry.scopes.get(root, ()) else file
        if declaration.conditional or registry.scopes[context].get(file, False):
            conditional = True
        link = (TypeLink('STRUCT', declaration.target) if declaration.target else
                registry.resolve(file, declaration.spelling, context))
        links.append(_qualify(link, declaration.qualifiers))
    identities = {(_type_identity(link), len(d.arrays)) for d, link in zip(declarations, links)}
    conditional |= any(link.status == 'CONDITIONAL' for link in links)
    if len(identities) != 1:
        return VariableBinding('CONDITIONAL' if conditional else 'AMBIGUOUS', declarations)
    if any(len({d.arrays[i] for d in declarations if d.arrays[i]}) > 1
           for i in range(len(declarations[0].arrays))):
        return VariableBinding('CONDITIONAL' if conditional else 'AMBIGUOUS', declarations)
    link = links[0]
    evidence = tuple(sorted(set().union(*(item.evidence for item in links),
                                        {d.origin for d in declarations})))
    status = 'CONDITIONAL' if conditional else link.status
    return VariableBinding(status, declarations, replace(link, status=status, evidence=evidence))

def _bind_variables(registry):
    groups = defaultdict(list)
    for unit in registry.units.values():
        for declaration in unit.variables:
            groups[declaration.name].append(declaration)

    includers = defaultdict(set)
    for file, scope in registry.scopes.items():
        for visible in scope:
            includers[visible].add(file)

    bindings = {}
    for name, items in groups.items():
        declarations = tuple(items)
        contexts = []
        visible_from = set().union(*(includers[d.origin.file] for d in declarations))
        for file in sorted(visible_from):
            scope = registry.scopes[file]
            local = tuple(d for d in declarations if d.origin.file in scope)
            local_files = {d.origin.file for d in local}
            static_files = {d.origin.file for d in local if d.storage == 'static'}
            if static_files:
                # Internal linkage belongs to a single translation unit.
                binding = (_bind_declarations(registry, local, file) if len(local_files) == 1
                           else VariableBinding('AMBIGUOUS', local))
            else:
                shared = {d.origin.file for d in local if d.storage == 'extern'
                          and d.origin.file != file and not scope[d.origin.file]}
                connected = tuple(d for d in declarations if d.origin.file not in scope
                                  and d.storage != 'static'
                                  and any(registry.scopes[d.origin.file].get(h) is False for h in shared))
                binding = _bind_declarations(registry, local + connected, file)
            bindings[file, name] = binding
            contexts.append(binding)

        if len({d.origin.file for d in declarations}) == 1 and not any(d.storage == 'static' for d in declarations):
            file = declarations[0].origin.file
            binding = bindings[file, name]
            # An incomplete header can have different completions in its includers.
            resolved = {b.type_link.definition for b in contexts if b.status == 'STRUCT'}
            if len(resolved) > 1 or any(b.status == 'AMBIGUOUS' for b in contexts):
                binding = VariableBinding('AMBIGUOUS', declarations)
        elif any(b.declarations and set(b.declarations) == set(declarations)
                 and b.status in ('STRUCT', 'INTEGER', 'SCALAR') for b in contexts) and not any(
                     d.storage == 'static' for d in declarations):
            binding = _bind_declarations(registry, declarations, None)
        elif (any(d.storage == 'extern' for d in declarations)
              and all(d.storage != 'static' for d in declarations)
              and len({d.origin.file for d in declarations if d.storage != 'extern'}) == 1):
            # A header declaration and one defining source can agree even if
            # no include edge was collected. Check every declaration's type.
            binding = _bind_declarations(registry, declarations, None)
        else:
            binding = VariableBinding('AMBIGUOUS' if len(declarations) > 1 else 'UNRESOLVED', declarations)
        bindings[None, name] = binding
    return {name: tuple(items) for name, items in groups.items()}, bindings


def _bind_functions(registry, globals_by_scope):
    groups = defaultdict(list)
    for unit in registry.units.values():
        for function in unit.functions:
            groups[function.name].append(function)

    from .function_parameters import signature_parts, array_parameter_binding

    functions = {}
    for name, declarations in groups.items():
        scopes = []
        for definition in (item for item in declarations if item.definition):
            file = definition.origin.file
            visible = registry.scopes[file]
            prototypes = [item for item in declarations if not item.definition
                          and item.origin.file in visible
                          and (not item.internal or item.origin.file == file)]
            status = 'CONDITIONAL' if definition.conditional else 'RESOLVED'
            if any(p.conditional or visible[p.origin.file] for p in prototypes):
                status = 'CONDITIONAL'
            definition_parts = signature_parts(registry, definition, file)
            unknown = {i for i, part in enumerate(definition_parts) if part is None}
            def parameter_evidence(function, index):
                parameter = function.parameters[index]
                origin = parameter.origin if parameter else function.origin
                return (f"{Path(origin.file).name}:{origin.line} "
                        f"({' '.join(function.raw_parameters[index])})")
            unknown_evidence = {i: [parameter_evidence(definition, i)] for i in unknown}
            conflicts = []
            for prototype in prototypes:
                location = f'{Path(prototype.origin.file).name}:{prototype.origin.line}'
                if tuple(w.casefold() for w in prototype.return_type) != tuple(w.casefold() for w in definition.return_type):
                    conflicts.append(f'반환 타입 불일치 ({location})')
                if not prototype.prototyped:
                    continue
                parts = signature_parts(registry, prototype, file)
                if len(parts) != len(definition_parts):
                    conflicts.append(f'매개변수 개수 불일치 ({location})')
                    continue
                for index, (declared, defined) in enumerate(zip(parts, definition_parts)):
                    if (declared == ('variadic',)) != (defined == ('variadic',)):
                        conflicts.append(f'{index + 1}번째 매개변수 가변 인자 불일치 ({location})')
                    elif declared is None or defined is None:
                        unknown.add(index)
                        if declared is None:
                            unknown_evidence.setdefault(index, []).append(parameter_evidence(prototype, index))
                    elif declared != defined:
                        conflicts.append(f'{index + 1}번째 매개변수 타입 불일치 ({location})')
            parameter_issues = {}
            uncollected = False
            for index in sorted(unknown):
                parameter = definition.parameters[index]
                if parameter is None:
                    uncollected = True
                    continue
                parameter_issues[parameter.name] = (
                    f"매개변수 '{parameter.name}'의 타입을 확정하지 못함 / "
                    f"함수 {name} / 타입 해석 실패 선언: " +
                    ' / '.join(dict.fromkeys(unknown_evidence[index])))
            linkage_reason = ''
            if conflicts:
                status = 'AMBIGUOUS'
                linkage_reason = ' / '.join(dict.fromkeys(conflicts))
            elif unknown:
                status = 'PARTIAL'
                labels = [definition.parameters[i].name if definition.parameters[i] else f'{i + 1}번째 인자'
                          for i in sorted(unknown)]
                linkage_reason = ('일부 매개변수 타입 미확정 (' + ', '.join(labels[:5]) +
                                  ') / 비교 대상 선언의 타입을 개별 확인')

            names = defaultdict(list)
            array_bindings = {}
            for index, parameter in enumerate(definition.parameters):
                if parameter:
                    names[parameter.name].append((parameter, False))
                    binding = array_parameter_binding(registry, definition, index, parameter, file)
                    if binding is not None:
                        array_bindings[parameter.name] = binding
            for declaration, nested in definition.locals:
                names[declaration.name].append((declaration, nested))
            variables = {}
            for variable, candidates in names.items():
                items = tuple(item for item, _ in candidates)
                nested = candidates[0][1]
                previous = globals_by_scope.get((file, variable))
                repeated_at_same_level = (len(items) > 1 and any(d.conditional for d in items)
                                          and all(not inner and d.kind != 'PARAMETER' for d, inner in candidates))
                if (len(items) != 1 and not repeated_at_same_level) or (nested and previous is not None):
                    binding = VariableBinding('AMBIGUOUS', items)
                elif len(items) == 1 and variable in array_bindings:
                    binding = array_bindings[variable]
                elif items[0].storage == 'extern':
                    if previous and previous.status not in ('STRUCT', 'INTEGER', 'SCALAR'):
                        binding = VariableBinding(previous.status, items)
                    else:
                        binding = _bind_declarations(registry, items + (previous.declarations if previous else ()), file)
                else:
                    binding = _bind_declarations(registry, items, file)
                if variable in parameter_issues:
                    # An unknown prototype or complex declarator must not use a
                    # same-named global, inferred struct or incomplete array type.
                    binding = replace(binding, status='UNRESOLVED', type_link=None)
                variables[variable] = replace(binding, nested_only=nested)
            scopes.append(FunctionScope(file, status, variables, parameter_issues=parameter_issues,
                                        linkage_reason=linkage_reason, uncollected_parameters=uncollected))
        if scopes:
            functions[name] = tuple(scopes)
    return functions


def build_bitfield_catalog(paths, encoding='utf-8-sig', *, sources=None, isolated=False):
    """Collect input files first, then link declarations by source scope.

    Includes supply the preferred context; missing types use all supplied files. Numeric ranges describe
    the declared width and signedness, without asserting target storage capacity or layout.
    """
    files = sorted({str(Path(path).resolve()) for path in paths})
    supplied = sources
    units, sources, diagnostics = {}, {}, []
    for file in files:
        if supplied is not None:
            sources[file] = supplied[file]
            continue
        try:
            raw = Path(file).read_bytes()
        except OSError as exc:
            diagnostics.append(Diagnostic(file, 1, str(exc), 'SOURCE_READ_ERROR'))
            units[file] = _Unit()
            continue
        for codec in dict.fromkeys((encoding, 'utf-8-sig', 'cp949', 'latin-1')):
            try:
                source = raw.decode(codec)
                break
            except UnicodeDecodeError:
                continue
        sources[file] = source
    units.update(_collect_units(sources, set(files)))
    diagnostics.extend(d for unit in units.values() for d in unit.reviews)
    registry = _Registry(units)
    registry.isolated = isolated
    links, aliases = {}, defaultdict(set)
    for file, scope in registry.scopes.items():
        names = {name for path in scope for name in units[path].types}
        for name in sorted(names):
            link = registry.resolve(file, name)
            links[file, name] = link
            if link.status == 'STRUCT' and not link.pointer_depth and not name.startswith('struct '):
                aliases[link.definition].add(name)
    definitions = {}
    for origin, (st, conditional) in registry.definitions.items():
        status = 'CONDITIONAL' if conditional else 'RESOLVED'
        for spelling in ('struct ' + st.tag, st.name) if st.tag else (st.name,):
            local = units[origin.file].types.get(spelling, ())
            if status == 'RESOLVED' and any(d.target == origin for d in local):
                link = links[origin.file, spelling]
                if link.status != 'STRUCT':
                    status = link.status
        counts = Counter(raw.member for raw in st.fields)
        fields = tuple(_field(raw, registry, status if status != 'RESOLVED' else
                              'AMBIGUOUS' if counts[raw.member] > 1 else '') for raw in st.fields)
        definitions[origin] = CatalogStruct(origin, st.name, st.tag,
                                             tuple(sorted(aliases[origin])), status, fields, tuple(st.ordinary))
    conditional = frozenset(origin for unit in units.values() for origin in unit.conditional_declarations)
    variables, bindings = _bind_variables(registry)
    catalog = BitfieldCatalog(definitions, links, tuple(diagnostics), registry.scopes, conditional,
                              variables, bindings, _bind_functions(registry, bindings))
    catalog.constant_value = registry.constant
    return catalog

